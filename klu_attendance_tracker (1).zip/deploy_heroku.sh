#!/bin/bash

# Check if Heroku CLI is installed
if ! command -v heroku &> /dev/null; then
    echo "Heroku CLI is not installed. Installing..."
    curl https://cli-assets.heroku.com/install.sh | sh
fi

# Create Procfile
echo "web: gunicorn app:app" > Procfile

# Add gunicorn to requirements.txt if not already there
if ! grep -q "gunicorn" requirements.txt; then
    echo "gunicorn==20.1.0" >> requirements.txt
fi

# Initialize git repository if not already initialized
if [ ! -d .git ]; then
    git init
    git add .
    git commit -m "Initial commit"
fi

# Login to Heroku
heroku login

# Create Heroku app
heroku create klu-attendance-tracker

# Push to Heroku
git push heroku master

echo "App deployed to Heroku successfully!"