#!/bin/bash

# Install Buildozer dependencies
apt-get update
apt-get install -y python3-pip build-essential git python3 python3-dev ffmpeg libsdl2-dev libsdl2-image-dev libsdl2-mixer-dev libsdl2-ttf-dev libportmidi-dev libswscale-dev libavformat-dev libavcodec-dev zlib1g-dev

# Install Buildozer
pip install --upgrade buildozer

# Install Android build tools
apt-get install -y openjdk-11-jdk autoconf automake libtool

# Build the APK
buildozer android debug

echo "APK built successfully! Check the bin/ directory for the APK file."