#!/bin/bash

# Install dependencies if not already installed
pip install -r requirements.txt

# Run the Flask app
python app.py