#!/bin/bash

# Check if port is provided
if [ -z "$1" ]; then
    echo "Usage: $0 <port>"
    echo "Example: $0 12000"
    exit 1
fi

# Install dependencies if not already installed
pip install -r requirements.txt

# Run the Flask app on the specified port
python -c "
import sys
from app import app
port = int(sys.argv[1])
app.run(host='0.0.0.0', port=port, debug=True)
" $1