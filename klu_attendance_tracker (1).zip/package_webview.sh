#!/bin/bash

# Create a directory for the WebView package
mkdir -p webview_package

# Copy all necessary files
cp -r webview_app/* webview_package/

# Create a zip file of the WebView package
zip -r klu_attendance_tracker_webview.zip webview_package

echo "WebView package created successfully! Check klu_attendance_tracker_webview.zip"