# KLU Attendance Tracker

A web application for Kalasalingam University students to track and manage their attendance.

## Author
- **Hasan** - [@hasanfq6](https://instagram.com/hasanfq6) on Instagram

## Features

- **Real-time Attendance**: View your current attendance for all courses
- **Future Attendance Prediction**: Calculate how your attendance percentage will change after future classes
- **Classes Needed Calculator**: Determine how many classes you need to attend to reach a target percentage
- **Absences Allowed Calculator**: Find out how many classes you can miss while maintaining minimum attendance
- **Manual Entry**: Enter attendance data manually if you don't want to log in to the KLU portal
- **Visual Analytics**: View your attendance data in charts and graphs
- **Progressive Web App**: Install on your device for offline access

## Installation

1. Clone the repository:
```bash
git clone https://github.com/hasanfq6/klu-attendance-tracker.git
cd klu-attendance-tracker
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Run the application:
```bash
python app.py
```

4. Open your browser and navigate to:
```
http://localhost:12000
```

## Usage

1. **Login**: Enter your KLU portal credentials to fetch your attendance data
2. **Dashboard**: View your attendance for all courses
3. **Calculations**: Use the tools to calculate future attendance, classes needed, and absences allowed
4. **Manual Entry**: If you don't want to use your portal credentials, you can manually enter your attendance data

## Technologies Used

- **Backend**: Python, Flask, aiohttp
- **Frontend**: HTML, CSS, JavaScript, Bootstrap 5
- **Data Visualization**: Chart.js
- **PWA Support**: Service Worker, Web Manifest

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Kalasalingam University for providing the student portal
- All the students who provided feedback and suggestions

## Contact

For any questions or suggestions, please contact:
- Instagram: [@hasanfq6](https://instagram.com/hasanfq6)