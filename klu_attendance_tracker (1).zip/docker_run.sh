#!/bin/bash

# Build the Docker image
docker build -t klu-attendance-tracker .

# Run the Docker container
docker run -p 12000:12000 klu-attendance-tracker