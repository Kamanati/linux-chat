# KLU Attendance Tracker WebView App

This is a simple Android WebView app that loads the KLU Attendance Tracker web application.

## How to Build

1. Create a new Android Studio project
2. Copy these files to the appropriate locations in your project
3. Update the URL in MainActivity.java to point to your deployed web application
4. Build the APK using Android Studio

## Files

- `MainActivity.java`: The main activity that loads the WebView
- `activity_main.xml`: The layout file for the main activity
- `AndroidManifest.xml`: The manifest file for the app

## Author

- **Hasan** - [@hasanfq6](https://instagram.com/hasanfq6) on Instagram