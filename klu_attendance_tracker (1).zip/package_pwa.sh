#!/bin/bash

# Create a directory for the PWA package
mkdir -p pwa_package

# Copy all necessary files
cp -r static templates app.py requirements.txt README.md pwa_package/

# Create a simple installation guide
cat > pwa_package/INSTALL.md << 'EOL'
# KLU Attendance Tracker PWA Installation Guide

## Installation on Android

1. Open the web app in Chrome: https://your-deployment-url.com
2. Tap the menu button (three dots) in the top-right corner
3. Tap "Add to Home Screen"
4. Follow the prompts to install the app

## Installation on iOS

1. Open the web app in Safari: https://your-deployment-url.com
2. Tap the Share button
3. Scroll down and tap "Add to Home Screen"
4. Follow the prompts to install the app

## Running the Web App Locally

1. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the Flask app:
   ```
   python app.py
   ```

3. Open your browser and navigate to:
   ```
   http://localhost:12000
   ```
EOL

# Create a simple deployment guide
cat > pwa_package/DEPLOY.md << 'EOL'
# Deployment Guide

## Deploying to Heroku

1. Create a Heroku account if you don't have one
2. Install the Heroku CLI
3. Login to Heroku:
   ```
   heroku login
   ```
4. Create a new Heroku app:
   ```
   heroku create klu-attendance-tracker
   ```
5. Create a Procfile:
   ```
   echo "web: gunicorn app:app" > Procfile
   ```
6. Add gunicorn to requirements.txt:
   ```
   echo "gunicorn==20.1.0" >> requirements.txt
   ```
7. Deploy to Heroku:
   ```
   git init
   git add .
   git commit -m "Initial commit"
   git push heroku master
   ```

## Deploying to PythonAnywhere

1. Create a PythonAnywhere account
2. Upload your files to PythonAnywhere
3. Create a new web app
4. Configure the web app to use Flask
5. Set the working directory to the directory containing app.py
6. Set the WSGI configuration file to point to your Flask app
EOL

# Create a zip file of the PWA package
zip -r klu_attendance_tracker_pwa.zip pwa_package

echo "PWA package created successfully! Check klu_attendance_tracker_pwa.zip"