# Deployment Guide

## Deploying to Heroku

1. Create a Heroku account if you don't have one
2. Install the Heroku CLI
3. Login to Heroku:
   ```
   heroku login
   ```
4. Create a new Heroku app:
   ```
   heroku create klu-attendance-tracker
   ```
5. Create a Procfile:
   ```
   echo "web: gunicorn app:app" > Procfile
   ```
6. Add gunicorn to requirements.txt:
   ```
   echo "gunicorn==20.1.0" >> requirements.txt
   ```
7. Deploy to Heroku:
   ```
   git init
   git add .
   git commit -m "Initial commit"
   git push heroku master
   ```

## Deploying to PythonAnywhere

1. Create a PythonAnywhere account
2. Upload your files to PythonAnywhere
3. Create a new web app
4. Configure the web app to use Flask
5. Set the working directory to the directory containing app.py
6. Set the WSGI configuration file to point to your Flask app
