# KLU Attendance Tracker PWA Installation Guide

## Installation on Android

1. Open the web app in Chrome: https://your-deployment-url.com
2. Tap the menu button (three dots) in the top-right corner
3. Tap "Add to Home Screen"
4. Follow the prompts to install the app

## Installation on iOS

1. Open the web app in Safari: https://your-deployment-url.com
2. Tap the Share button
3. Scroll down and tap "Add to Home Screen"
4. Follow the prompts to install the app

## Running the Web App Locally

1. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the Flask app:
   ```
   python app.py
   ```

3. Open your browser and navigate to:
   ```
   http://localhost:12000
   ```
