#!/usr/bin/env python3
"""
Kalasalingam University Attendance Tracker
Author: Hasan
Contact: @hasanfq6 (Instagram)
"""

import os
import json
import asyncio
import aiohttp
from bs4 import BeautifulSoup
from lxml import html
import urllib3
from flask import Flask, render_template, request, jsonify, session, redirect, url_for, flash
import secrets
from datetime import datetime

# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

# Constants
LOGIN_URL = 'https://student.kalasalingam.ac.in/login'
ATTENDANCE_URL = 'https://student.kalasalingam.ac.in/attendance-details'
DASHBOARD_URL = 'https://student.kalasalingam.ac.in/'

# Utility functions
def find_name(html_content):
    try:
        tree = html.fromstring(html_content)
        name = tree.xpath('//td[text()="Name of the Student"]/following-sibling::td/text()')
        return name[0] if name else 'Name not found'
    except Exception as e:
        return f"An error occurred: {e}"

async def fetch_attendance(register_no, password):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    
    async with aiohttp.ClientSession() as session:
        # Get CSRF token
        async with session.get(LOGIN_URL, headers=headers, ssl=False, timeout=100) as response:
            response_text = await response.text()
            soup = BeautifulSoup(response_text, 'html.parser')
            csrf_token = soup.find('input', {'name': '_token'})['value']
            
            # Login
            login_data = {'register_no': register_no, 'password': password, '_token': csrf_token}
            async with session.post(LOGIN_URL, data=login_data, headers=headers, ssl=False) as response:
                if response.status == 200 and "Dashboard" in await response.text():
                    # Fetch attendance data
                    async with session.get(ATTENDANCE_URL, headers=headers, ssl=False) as grade_response:
                        # Fetch user profile for name
                        async with session.get(DASHBOARD_URL, headers=headers, ssl=False) as name_response:
                            try:
                                name_html = await name_response.text()
                                attendance_data = await grade_response.json()
                                return {
                                    'success': True,
                                    'name': find_name(name_html),
                                    'data': attendance_data
                                }
                            except Exception as e:
                                return {
                                    'success': False,
                                    'error': f'Failed to parse response: {str(e)}'
                                }
                else:
                    return {
                        'success': False,
                        'error': 'Login failed. Please check your credentials.'
                    }

def calculate_future_attendance(total, present, num_future_classes):
    """Calculate future attendance percentage after attending/missing classes"""
    new_total = total + num_future_classes
    
    # If attending all future classes
    new_present_all = present + num_future_classes
    percentage_all = (new_present_all / new_total) * 100 if new_total > 0 else 0
    
    # If missing all future classes
    percentage_none = (present / new_total) * 100 if new_total > 0 else 0
    
    return {
        'new_total': new_total,
        'percentage_if_attend_all': round(percentage_all, 2),
        'percentage_if_miss_all': round(percentage_none, 2)
    }

def calculate_classes_needed(total, present, target_percentage):
    """Calculate how many classes needed to attend to reach target percentage"""
    if target_percentage <= 0:
        return {'classes_needed': 0, 'is_possible': True}
    
    current_percentage = (present / total) * 100 if total > 0 else 0
    
    if current_percentage >= target_percentage:
        return {
            'classes_needed': 0,
            'is_possible': True,
            'message': 'You have already reached the target percentage.'
        }
    
    # Formula: (present + x) / (total + x) = target_percentage / 100
    # Solving for x: x = (target_percentage * total - 100 * present) / (100 - target_percentage)
    
    if target_percentage == 100:
        classes_needed = float('inf')  # Cannot reach 100% if already missed classes
        is_possible = present == total
    else:
        classes_needed = (target_percentage * total - 100 * present) / (100 - target_percentage)
        classes_needed = max(0, round(classes_needed))
        is_possible = True
    
    return {
        'classes_needed': classes_needed,
        'is_possible': is_possible,
        'message': 'Not possible to reach target percentage' if not is_possible else None
    }

def calculate_absences_allowed(total, present, min_percentage):
    """Calculate how many more classes can be missed while maintaining minimum percentage"""
    current_percentage = (present / total) * 100 if total > 0 else 0
    
    if current_percentage < min_percentage:
        return {
            'absences_allowed': 0,
            'is_possible': False,
            'message': f'Current attendance ({current_percentage:.2f}%) is already below minimum ({min_percentage}%).'
        }
    
    # Formula: present / (total + x) = min_percentage / 100
    # Solving for x: x = (100 * present - min_percentage * total) / min_percentage
    
    absences_allowed = (100 * present - min_percentage * total) / min_percentage
    absences_allowed = max(0, int(absences_allowed))
    
    return {
        'absences_allowed': absences_allowed,
        'is_possible': True
    }

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['POST'])
async def login():
    register_no = request.form.get('register_no')
    password = request.form.get('password')
    
    if not register_no or not password:
        flash('Please provide both register number and password')
        return redirect(url_for('index'))
    
    result = await fetch_attendance(register_no, password)
    
    if result['success']:
        session['user_data'] = {
            'register_no': register_no,
            'name': result['name'],
            'attendance': result['data']
        }
        return redirect(url_for('dashboard'))
    else:
        flash(result['error'])
        return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    if 'user_data' not in session:
        flash('Please login first')
        return redirect(url_for('index'))
    
    return render_template('dashboard.html', 
                          user_data=session['user_data'],
                          current_date=datetime.now().strftime('%Y-%m-%d'))

@app.route('/calculate', methods=['POST'])
def calculate():
    if 'user_data' not in session:
        return jsonify({'success': False, 'error': 'Not logged in'})
    
    course_code = request.form.get('course_code')
    action = request.form.get('action')
    
    # Find the course data
    course_data = None
    for course in session['user_data']['attendance']['data']:
        if course['course_code'] == course_code:
            course_data = course
            break
    
    if not course_data:
        return jsonify({'success': False, 'error': 'Course not found'})
    
    total = int(course_data['total'])
    present = int(course_data['present'])
    
    if action == 'future_attendance':
        num_future_classes = int(request.form.get('num_future_classes', 0))
        result = calculate_future_attendance(total, present, num_future_classes)
        return jsonify({'success': True, 'result': result})
    
    elif action == 'classes_needed':
        target_percentage = float(request.form.get('target_percentage', 75))
        result = calculate_classes_needed(total, present, target_percentage)
        return jsonify({'success': True, 'result': result})
    
    elif action == 'absences_allowed':
        min_percentage = float(request.form.get('min_percentage', 75))
        result = calculate_absences_allowed(total, present, min_percentage)
        return jsonify({'success': True, 'result': result})
    
    return jsonify({'success': False, 'error': 'Invalid action'})

@app.route('/manual_entry', methods=['GET', 'POST'])
def manual_entry():
    if request.method == 'GET':
        return render_template('manual_entry.html')
    
    # Process manual entry form
    name = request.form.get('name')
    register_no = request.form.get('register_no')
    courses_json = request.form.get('courses')
    
    try:
        courses = json.loads(courses_json)
        
        # Create user data structure
        user_data = {
            'register_no': register_no,
            'name': name,
            'attendance': {
                'data': courses
            }
        }
        
        session['user_data'] = user_data
        return redirect(url_for('dashboard'))
    
    except Exception as e:
        flash(f'Error processing data: {str(e)}')
        return redirect(url_for('manual_entry'))

@app.route('/logout')
def logout():
    session.pop('user_data', None)
    flash('You have been logged out')
    return redirect(url_for('index'))

@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 12000))
    app.run(host='0.0.0.0', port=port, debug=True)