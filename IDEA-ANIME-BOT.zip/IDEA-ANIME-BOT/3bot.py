import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import requests
import json
import time
import random
from main import *

API_TOKEN = '7476477687:AAG0b8QdVKO5zvbTYQ95WKN7C9F_i94714I'
bot = telebot.TeleBot(API_TOKEN)

# Function to rewrite wp_ids.json with the latest data
def update_wp_ids():
    url = 'https://toonhub4u.net/wp-json/wp/v2/posts/'
    response = requests.get(url)
    data = response.json()
    
    # Extract only the ID and save it to wp_ids.json
    ids = [{'id': post['id']} for post in data]
    
    with open('wp_ids.json', 'w') as file:
        json.dump(ids, file, indent=4)
    
    return ids

# Function to fetch the last episode ID from wp_ids.json
def get_last_episode_id():
    with open('wp_ids.json', 'r') as file:
        ids = json.load(file)
        if ids:
            return ids[0]['id']  # The first ID is the most recent one
    return None

# Function to shorten link with GPLinks if it's the last episode
def shorten_link_if_last_episode(url, episode_id):
    last_episode_id = get_last_episode_id()
    if episode_id == last_episode_id:
        gplink_api = f'https://api.gplinks.com/api?api=YOUR_GPLINKS_API_TOKEN&url={url}'
        response = requests.get(gplink_api)
        data = response.json()
        if data['status'] == 'success':
            return data['shortenedUrl']
    return url

# Function to save search history in JSON
def save_search_data(user_id, search_query):
    search_data = {'user_id': user_id, 'search_query': search_query}
    
    with open('search_history.json', 'a') as file:
        json.dump(search_data, file, indent=4)

# Handler for search queries
@bot.message_handler(commands=['search'])
def handle_search(message):
    user_id = message.from_user.id
    search_query = message.text.replace('/search ', '')
    
    # Save the search query
    save_search_data(user_id, search_query)
    
    # Get search results (this is where your pre-created search function would be used)
    search_results = search(search_query, page=1, per_page=10) 
    
    markup = InlineKeyboardMarkup()
    for title, episode_id in search_results:
        markup.add(InlineKeyboardButton(title, callback_data=f"select_{episode_id}"))
    
    bot.send_message(user_id, "Select an anime:", reply_markup=markup)

# Handler for selecting an anime from search results
@bot.callback_query_handler(func=lambda call: call.data.startswith('select_'))
def handle_anime_selection(call):
    episode_id = int(call.data.split('_')[1])
    
    # Fetch anime details (using your pre-created extract_data function)
    anime_data = extract_data(episode_id)
    
    img_url = anime_data['img_url']
    title = anime_data['Title']
    languages = anime_data['Language']
    quality_options = anime_data['Episodes']
    
    # Create an inline keyboard for selecting quality
    markup = InlineKeyboardMarkup()
    for quality in quality_options.keys():
        markup.add(InlineKeyboardButton(quality, callback_data=f"quality_{episode_id}_{quality}"))
    
    # Add Back button
    markup.add(InlineKeyboardButton("Back", callback_data=f"back_to_search"))
    
    # Send image with caption and quality selection
    bot.send_photo(call.message.chat.id, img_url, caption=f"**{title}**\n\n**Languages:** {languages}", parse_mode="Markdown", reply_markup=markup)

# Handler for back to search
@bot.callback_query_handler(func=lambda call: call.data == 'back_to_search')
def handle_back_to_search(call):
    user_id = call.message.chat.id
    # Re-send the search query menu
    search_query = ' '.join(call.message.text.split()[1:])
    search_results = search(search_query, page=1, per_page=10)
    
    markup = InlineKeyboardMarkup()
    for title, episode_id in search_results:
        markup.add(InlineKeyboardButton(title, callback_data=f"select_{episode_id}"))
    
    bot.send_message(user_id, "Select an anime:", reply_markup=markup)

# Handler for selecting quality
@bot.callback_query_handler(func=lambda call: call.data.startswith('quality_'))
def handle_quality_selection(call):
    _, episode_id, selected_quality = call.data.split('_')
    
    # Fetch anime details again
    anime_data = extract_data(int(episode_id))
    episode_options = anime_data['Episodes'][selected_quality]
    
    # Create a grid of episodes
    markup = InlineKeyboardMarkup(row_width=3)
    for episode, url in episode_options.items():
        markup.add(InlineKeyboardButton(episode, callback_data=f"episode_{episode_id}_{selected_quality}_{episode}"))
    
    # Add Back button
    markup.add(InlineKeyboardButton("Back", callback_data=f"back_to_quality_{episode_id}"))
    
    # Edit the message to ask for episode selection
    bot.edit_message_caption(chat_id=call.message.chat.id, message_id=call.message.message_id, caption=f"**Select an episode** for **{selected_quality}** quality:", parse_mode="Markdown", reply_markup=markup)

# Handler for back to quality selection
@bot.callback_query_handler(func=lambda call: call.data.startswith('back_to_quality_'))
def handle_back_to_quality(call):
    _, episode_id = call.data.split('_')[1:]
    
    # Fetch anime details again
    anime_data = extract_data(int(episode_id))
    quality_options = anime_data['Episodes']
    
    # Create an inline keyboard for selecting quality
    markup = InlineKeyboardMarkup()
    for quality in quality_options.keys():
        markup.add(InlineKeyboardButton(quality, callback_data=f"quality_{episode_id}_{quality}"))
    
    # Add Back button
    markup.add(InlineKeyboardButton("Back", callback_data=f"back_to_search"))
    
    # Edit the message to show quality selection
    bot.edit_message_caption(chat_id=call.message.chat.id, message_id=call.message.message_id, caption=f"**Languages:** {anime_data['Language']}\n\nSelect a quality:", parse_mode="Markdown", reply_markup=markup)

# Handler for selecting an episode
@bot.callback_query_handler(func=lambda call: call.data.startswith('episode_'))
def handle_episode_selection(call):
    _, episode_id, selected_quality, selected_episode = call.data.split('_')
    
    # Fetch anime details again
    anime_data = extract_data(int(episode_id))
    episode_url = anime_data['Episodes'][selected_quality][selected_episode]
    
    # Shorten the link if it's the last episode
    final_url_ = shorten_link_if_last_episode(episode_url, int(episode_id))
    final_url = final_bot_url(final_url_)
    # Send the final download link
    bot.send_message(call.message.chat.id, f"[Click here to download {selected_episode}]({final_url})", parse_mode="Markdown")

# Function to monitor the WordPress API periodically
def monitor_wp_api():
    while True:
        update_wp_ids()
        
        # Wait for a random time between 2 to 5 minutes before checking again
        time.sleep(random.randint(120, 300))

# Start the WordPress API monitoring in a separate thread
import threading
monitoring_thread = threading.Thread(target=monitor_wp_api)
monitoring_thread.start()

# Start the bot
bot.polling()
