import argparse
import requests
import aria2p

# Constants
BASE_URL = "allanime.to"
SEARCH_GQL = """
query($search: SearchInput, $limit: Int, $page: Int, $translationType: VaildTranslationTypeEnumType, $countryOrigin: VaildCountryOriginEnumType) {
    shows(search: $search, limit: $limit, page: $page, translationType: $translationType, countryOrigin: $countryOrigin) {
        edges {
            _id
            name
            availableEpisodes
            __typename
        }
    }
}
"""

EPISODE_EMBED_GQL = """
query ($showId: String!, $translationType: VaildTranslationTypeEnumType!, $episodeString: String!) {
    episode(showId: $showId, translationType: $translationType, episodeString: $episodeString) {
        episodeString
        sourceUrls
    }
}
"""

# Functions
def make_graphql_request(query, variables):
    url = f"https://{BASE_URL}/api"
    headers = {
        "Content-Type": "application/json",
        "Referer": f"https://{BASE_URL}",
    }
    payload = {
        "query": query,
        "variables": variables,
    }
    response = requests.post(url, json=payload, headers=headers)
    return response.json()

def search_anime(search_term):
    variables = {
        "search": {"query": search_term},
        "limit": 5,
        "page": 1,
        "translationType": "sub",
        "countryOrigin": "JP",
    }
    response = make_graphql_request(SEARCH_GQL, variables)
    return response["data"]["shows"]["edges"]

def get_episode_links(show_id, episode_number):
    variables = {
        "showId": show_id,
        "translationType": "sub",
        "episodeString": f"Episode {episode_number}",
    }
    response = make_graphql_request(EPISODE_EMBED_GQL, variables)
    return response["data"]["episode"]["sourceUrls"]

def download_episode(download_url, output_path):
    aria2 = aria2p.API(
        aria2p.Client(
            host="http://localhost",
            port=6800,
            secret=""
        )
    )
    download = aria2.add_uris([download_url], {"out": output_path})
    return download

# Main function
def main():
    parser = argparse.ArgumentParser(description="Anime Downloader Script")
    parser.add_argument("anime_name", type=str, help="Name of the anime to search for")
    parser.add_argument("episode_number", type=int, help="Episode number to download")

    args = parser.parse_args()
    anime_name = args.anime_name
    episode_number = args.episode_number

    # Search Anime
    anime_list = search_anime(anime_name)
    if not anime_list:
        print("No anime found with that name.")
        return

    # Let the user select the anime
    print("Select the anime:")
    for i, anime in enumerate(anime_list):
        print(f"{i + 1}. {anime['name']} ({anime['availableEpisodes']} episodes available)")

    selection = int(input("\nEnter the number corresponding to the anime: ")) - 1
    selected_anime = anime_list[selection]

    # Fetch Episode Links
    episode_links = get_episode_links(selected_anime["_id"], episode_number)
    if not episode_links:
        print("No links found for the specified episode.")
        return

    # Download the episode
    output_filename = f"{selected_anime['name']}_Episode_{episode_number}.mp4"
    download = download_episode(episode_links[0], output_filename)
    print(f"Downloading {selected_anime['name']} Episode {episode_number}...")

    # Monitor the download progress
    while not download.is_complete:
        progress = download.progress_string()
        print(f"Download Progress: {progress}", end="\r")
    print("\nDownload complete!")

if __name__ == "__main__":
    main()
