import time
import cloudscraper
from bs4 import BeautifulSoup
import requests

# Example URL
url = "https://gplinks.co/Z94r6"

def gplinks_bypass(url: str):
        client = cloudscraper.create_scraper(allow_brotli=False)  
        domain = "https://gplinks.co/"
        referer = "https://mynewsmedia.co/"

    #try:
        # Get the initial redirect URL
        response = client.get("https://gplinks.co/jV3rpX", allow_redirects=True)
        print(response.headers)
        print(response.url)
        print(response.text)

        time.sleep(66)
        vid = response.headers.get("Location", "").split("=")[-1]
        url = f"{domain}?{vid}"

        # Fetch the bypass page
        response = client.get(url, allow_redirects=False)
        soup = BeautifulSoup(response.content, "html.parser")

        # Extract form data
        inputs = soup.find(id="go-link").find_all(name="input")
        data = {input.get('name'): input.get('value') for input in inputs}

        # Post form data to bypass the link
        time.sleep(10)  # Optional delay
        headers = {"x-requested-with": "XMLHttpRequest"}
        bypassed_url = client.post(domain + "links/go", data=data, headers=headers).json().get("url")

        return bypassed_url

    #except Exception as e:
        print(f"An error occurred: {e}")
        return None

print(gplinks_bypass(url)) 
