import telebot
from telebot import types
from main import search, extract_data, final_bot_url  # Replace with the actual file name


# Replace with your bot token
BOT_TOKEN = '7420318554:AAFazGm82OokBD-LEA3NTm38A3tEL9LeD60'
bot = telebot.TeleBot(BOT_TOKEN)

# Global variables to hold user state
user_state = {}
user_data = {}

# Keyboard buttons
def get_quality_keyboard():
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add('480p', '720p', '1080p')
    return keyboard

def get_episode_selection_keyboard(total_episodes):
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    buttons = [f'{i}' for i in range(1, total_episodes + 1)]
    keyboard.add(*buttons)
    keyboard.add('Range (e.g., 1-7)')
    return keyboard

# Start command handler
@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(message.chat.id, "Welcome! Please search for an anime.")
    bot.register_next_step_handler(message, handle_search)

def handle_search(message):
    user_id = message.chat.id
    search_query = message.text
    user_state[user_id] = 'search'
    
    search_results = search(search_query)
    
    if not search_results:
        bot.send_message(message.chat.id, "No results found. Please try again.")
        return

    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    for title, id in search_results:
        markup.add(title)
    
    bot.send_message(message.chat.id, "Select an anime:", reply_markup=markup)
    bot.register_next_step_handler(message, handle_anime_selection)

def handle_anime_selection(message):
    user_id = message.chat.id
    selected_title = message.text
    user_state[user_id] = 'quality'
    
    # Retrieve the anime ID
    search_results = search("")  # Empty query to get all results (adjust as needed)
    selected_id = next((id for title, id in search_results if title == selected_title), None)
    
    if selected_id is None:
        bot.send_message(message.chat.id, "Invalid selection. Please start again.")
        return

    # Extract data for the selected anime
    data = extract_data(selected_id)
    user_data[user_id] = data
    
    # Show quality options
    bot.send_message(message.chat.id, "Select the quality of the episodes:", reply_markup=get_quality_keyboard())
    bot.register_next_step_handler(message, handle_quality_selection)

def handle_quality_selection(message):
    user_id = message.chat.id
    selected_quality = message.text
    user_data[user_id]['selected_quality'] = selected_quality
    
    # Get the number of episodes
    total_episodes = len(user_data[user_id]['Episodes'])
    
    # Show episode selection options
    bot.send_message(message.chat.id, f"This anime has {total_episodes} episodes. Please select an episode or range:", reply_markup=get_episode_selection_keyboard(total_episodes))
    bot.register_next_step_handler(message, handle_episode_selection)

def handle_episode_selection(message):
    user_id = message.chat.id
    episode_selection = message.text
    data = user_data[user_id]
    
    if 'Range' in episode_selection:
        # Handle episode range
        # Implement logic to parse and validate episode ranges
        pass
    else:
        # Handle single episode
        episode_number = int(episode_selection)
        if episode_number in data['Episodes']:
            quality = data['selected_quality']
            episode_url = data['Episodes'][f'Episode {episode_number}'][quality]
            final_url = final_bot_url(episode_url)
            bot.send_message(message.chat.id, f"Download link: {final_url}")
        else:
            bot.send_message(message.chat.id, "Invalid episode number. Please start again.")
    
    # Reset user state
    user_state[user_id] = None

# Polling for new messages
bot.polling()
