import requests
import re
import pprint

import requests

import requests
from bs4 import BeautifulSoup

def get_bot_link(url):
    # Step 1: Fetch the webpage
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')

    # Step 2: Extract the values from the hidden input fields
    filename = soup.find('input', {'id': 'filename'})['value']
    fileurl = soup.find('input', {'id': 'fileurl'})['value']
    vkshareid = soup.find('input', {'id': 'vkshareid'})['value']
    gdmrid = soup.find('input', {'id': 'gdmrid'})['value']

    # Step 3: Make the POST request to the API
    api_url = 'https://vkshare.online/vk/vkinfo.php?action=handleVKFile'
    data = {
        'fileurl': filename,
        'filename': fileurl,
        'vkid': vkshareid,
        'gdmrid': gdmrid,
    }
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
    }
    response = requests.post(api_url, data=data, headers=headers)

    # Step 4: Process the response to get the final link
    final_link = response.text.replace('"', '')

    # Step 5: Construct the Telegram bot link
    bot_link = f'https://t.me/gdmorebot?start={final_link}'

    return bot_link

# Example usage:
"""
url = "https://snapinsta.storyy.shop/files/92460b2ce0e5"
final_bot_link = get_final_bot_link(url)
print("Final Bot Link:", final_bot_link)	
"""

def search(search_term, page=1, per_page=10):
    # Base URL for the API
    base_url = "https://toonhub4u.net/wp-json/wp/v2/posts"

    # Parameters for the API call
    params = {
        "context": "view",       # Using "view" context
        "search": search_term,   # Using the provided search term
        "page": page,            # Optional: to specify page number
        "per_page": per_page     # Optional: to limit the number of posts returned
    }

    # Sending a GET request to the API
    response = requests.get(base_url, params=params)
    
    # Checking if the request was successful
    if response.status_code == 200:
        posts = response.json()  # Parsing the response as JSON
        results = [(post['title']['rendered'], post['id']) for post in posts]
        return results
    else:
        print(f"Failed to retrieve posts. Status code: {response.status_code}")
        return None

# Example usage
"""
if __name__ == "__main__":
    search_term = "one piece"
    posts = fetch_posts(search_term)
    if posts:
        for title, post_id in posts:
            print(f"Title: {title}")
            print(f"ID: {post_id}")
"""

def extractdata(id):
    # Fetching the JSON data from the URL
    response = requests.get(f"https://toonhub4u.net/wp-json/wp/v2/posts/{id}")
    data = response.json()

    # Extracting the required information
    title = data["title"]["rendered"]
    excerpt = data["excerpt"]["rendered"]

    # Extracting image URL
    image_url = re.search(r'src="([^"]+)"', data["content"]["rendered"]).group(1)

    # Extracting language and quality from the excerpt
    language_match = re.search(r'Language:\s*([^<]+)', excerpt)
    quality_match = re.search(r'Quality:\s*([^<]+)', excerpt)

    language = language_match.group(1).strip() if language_match else "N/A"
    quality = quality_match.group(1).strip() if quality_match else "N/A"

    # Extracting episode links
    episode_links = {}
    episode_pattern = re.compile(r'Episode\s+\d+.*?<\/p>(.*?)<hr', re.DOTALL)
    quality_pattern = re.compile(r'(\d+p)\s+–\s+<a href="([^"]+)"')

    for match in episode_pattern.finditer(data["content"]["rendered"]):
        episode_info = match.group(1)
        quality_links = {quality: link for quality, link in quality_pattern.findall(episode_info)}
        episode_links[f"Episode {len(episode_links)+1}"] = quality_links

    # Organizing the data in a structured manner
    result = {
        "img_url": image_url,
        "Title": title,
        "Language": language.replace("\xa0", ' '),
        "Quality": quality,
        "Episodes": episode_links
    }

    return result

# Example usage
"""
url = "https://toonhub4u.net/wp-json/wp/v2/posts/18729"
anime_data = extract_anime_data(url)
pprint.pprint(anime_data) 
"""
