import telebot
from telebot.types import InlineQueryResultArticle, InputTextMessageContent, ReplyKeyboardMarkup, KeyboardButton
from uuid import uuid4
from main import *
bot = telebot.TeleBot("7420318554:AAFazGm82OokBD-LEA3NTm38A3tEL9LeD60")
context_data = {}  # Temporary storage for user data

@bot.inline_handler(func=lambda query: len(query.query) > 0)
def inline_search(query):
    search_query = query.query
    results = search(search_query, page=1, per_page=10)
    
    articles = []
    for title, id in results:
        articles.append(
            InlineQueryResultArticle(
                id=str(uuid4()),
                title=title,
                input_message_content=InputTextMessageContent(id)
            )
        )
    
    bot.answer_inline_query(query.id, articles)

@bot.message_handler(func=lambda message: True)
def handle_message(message):
    selected_id = message.text.strip()

    # Check if it's a digit (an episode number) or an ID from the search
    if selected_id.isdigit():  # If it's an episode number
        data = context_data.get(message.chat.id)
        
        if data:
            episode_data = data['Episodes'].get(f'Episode {selected_id}')
            
            if episode_data:
                markdown_message = f"*{data['Title']}*\n\n"
                markdown_message += f"**Language:** {data['Language']}\n\n"
                markdown_message += f"*Episode {selected_id}:*\n"
                
                for quality, url in episode_data.items():
                    markdown_message += f"[{quality}]({final_bot_url(url)})\n"
                
                bot.send_message(message.chat.id, markdown_message, parse_mode="Markdown")
            else:
                bot.send_message(message.chat.id, "Episode not found.")
        else:
            bot.send_message(message.chat.id, "No data found. Please start the search again.")
        
        # Clear the context data after use
        context_data.pop(message.chat.id, None)

    else:  # If it's an ID from search results
        try:
            data = extract_data(selected_id)
            if data and 'Episodes' in data:
                context_data[message.chat.id] = data

                # Create a keyboard with episode numbers
                keyboard = ReplyKeyboardMarkup(row_width=3, resize_keyboard=True)
                buttons = [KeyboardButton(str(episode.split(' ')[1])) for episode in data['Episodes'].keys()]
                keyboard.add(*buttons)

                bot.send_message(message.chat.id, "Select the episode number:", reply_markup=keyboard)
            else:
                bot.send_message(message.chat.id, "Failed to retrieve episode data. Please try again.")
        except Exception as e:
            bot.send_message(message.chat.id, f"An error occurred: {str(e)}. Please try again.")

bot.polling() 
