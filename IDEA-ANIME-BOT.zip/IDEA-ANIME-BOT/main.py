import requests
import re
import pprint
from bs4 import BeautifulSoup
import base64
from urllib.parse import unquote
from functools import lru_cache

def decode_url(encoded_url):

    encoded_part = encoded_url.split('?url=')[-1]

    decoded_bytes = base64.urlsafe_b64decode(encoded_part)

    decoded_url = decoded_bytes.decode('utf-8')
    
    return decoded_url
@lru_cache(maxsize=100)
def final_bot_url(url):
    # Step 1: Fetch the webpage
    if "gplinks" in url:
          return url

    if "toonhub" in url:
          url_ = decode_url(url)
          url = url_

    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')


    # Step 2: Extract the values from the hidden input fields
    filename = soup.find('input', {'id': 'filename'})['value']
    fileurl = soup.find('input', {'id': 'fileurl'})['value']
    vkshareid = soup.find('input', {'id': 'vkshareid'})['value']
    gdmrid = soup.find('input', {'id': 'gdmrid'})['value']

    # Step 3: Make the POST request to the API
    api_url = 'https://vkshare.online/vk/vkinfo.php?action=handleVKFile'
    data = {
        'fileurl': filename,
        'filename': fileurl,
        'vkid': vkshareid,
        'gdmrid': gdmrid,
    }
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
    }
    response = requests.post(api_url, data=data, headers=headers)

    # Step 4: Process the response to get the final link
    final_link = response.text.replace('"', '')

    # Step 5: Construct the Telegram bot link
    bot_link = f'https://t.me/gdmorebot?start={final_link}'

    return bot_link

# Example usage:
"""
url = "https://gplinks.co/dleyhvqm"
final_bot_link = final_bot_url(url)
print("Final Bot Link:", final_bot_link)	
"""
@lru_cache(maxsize=100)
def search(search_term, page=1, per_page=10,url=False):
    # Base URL for the API
    base_url = "https://toonhub4u.net/wp-json/wp/v2/posts"

    # Parameters for the API call
    params = {
        "context": "view",       # Using "view" context
        "search": search_term,   # Using the provided search term
        "page": page,            # Optional: to specify page number
        "per_page": per_page     # Optional: to limit the number of posts returned
    }

    # Sending a GET request to the API
    if url:
        response = requests.get(base_url)
    else:
        response = requests.get(base_url, params=params)
    
    # Checking if the request was successful
    if response.status_code == 200:
        posts = response.json()  # Parsing the response as JSON
        results = [(post['title']['rendered'], post['id']) for post in posts]
        return results
    else:
        print(f"Failed to retrieve posts. Status code: {response.status_code}")
        return None

# Example usage
"""
if __name__ == "__main__":
    search_term = "one piece"
    posts = fetch_posts(search_term)
    if posts:
        for title, post_id in posts:
            print(f"Title: {title}")
            print(f"ID: {post_id}")
"""
"""
def extract_data(id):
    # Fetching the JSON data from the URL
    response = requests.get(f"https://toonhub4u.net/wp-json/wp/v2/posts/{id}")
    data = response.json()

    # Extracting the required information
    title = data["title"]["rendered"]
    excerpt = data["excerpt"]["rendered"]

    image_url_1 = re.search(r'<a\s+href="([^"]+)"\s+target="_blank"\s+rel="noopener">', data["content"]["rendered"]).group(1)
    # Extracting image URL
    image_url = re.search(r'src="([^"]+)"', data["content"]["rendered"]).group(1)

    # Extracting language and quality from the excerpt
    language_match = re.search(r'Language:\s*([^<]+)', excerpt)
    quality_match = re.search(r'Quality:\s*([^<]+)', excerpt)

    language = language_match.group(1).strip() if language_match else "N/A"
    quality = quality_match.group(1).strip() if quality_match else "N/A"

    # Extracting episode links
    episode_links = {}
    episode_pattern = re.compile(r'Episode\s+\d+.*?<\/p>(.*?)<hr', re.DOTALL)
    quality_pattern = re.compile(r'(\d+p)\s+–\s+<a href="([^"]+)"')

    for match in episode_pattern.finditer(data["content"]["rendered"]):
        episode_info = match.group(1)
        quality_links = {quality: link for quality, link in quality_pattern.findall(episode_info)}
        episode_links[f"Episode {len(episode_links)+1}"] = quality_links

    # Organizing the data in a structured manner
    result = {
        "img_url_1":image_url_1,
        "img_url": image_url,
        "Title": title,
        "Language": language.replace("\xa0", ' '),
        "Quality": quality,
        "Episodes": episode_links
    }

    return result
"""

def extract_data(id):
    # Fetching the JSON data from the URL
    response = requests.get(f"https://toonhub4u.net/wp-json/wp/v2/posts/{id}")
    data = response.json()

    # Extracting the required information
    title = data["title"]["rendered"]
    excerpt = data["excerpt"]["rendered"]
    # Extracting primary image URLs
    image_url_1 = re.search(r'<a\s+href="([^"]+)"\s+target="_blank"\s+rel="noopener">', data["content"]["rendered"])
    image_url = re.search(r'src="([^"]+)"', data["content"]["rendered"])

    # If regex finds no match, we set the value to None
    image_url_1 = image_url_1.group(1) if image_url_1 else None
    image_url = image_url.group(1) if image_url else None

    # Extracting language and quality from the content
    language_match = re.search(r'Language:\s*([^<]+)', excerpt)
    quality_match = re.search(r'Quality:\s*([^<]+)', excerpt)

    language = language_match.group(1).strip() if language_match else "N/A"
    quality = quality_match.group(1).strip() if quality_match else "N/A"

    # Attempt to extract episode links using regular logic
    episode_links = extract_episodes(data["content"]["rendered"])

    # If no episodes are found, use fallback logic
    if not episode_links:
        episode_links = extract_fallback_episodes(data["content"]["rendered"])

    # Organizing the data in a structured manner
    result = {
        "img_url_1": image_url_1,
        "img_url": image_url,
        "Title": title,
        "Language": language.replace("\xa0", ' '),
        "Quality": quality.replace("\xa0", ' '),
        "Episodes": episode_links
    }

    return result

def extract_episodes(content):
    """Regular extraction logic for episodes."""
    episode_links = {}
    episode_pattern = re.compile(r'Episode\s+\d+.*?<\/p>(.*?)<hr', re.DOTALL)
    quality_pattern = re.compile(r'(\d+p)\s+–\s+<a href="([^"]+)"')

    for match in episode_pattern.finditer(content):
        episode_info = match.group(1)
        quality_links = {quality: link for quality, link in quality_pattern.findall(episode_info)}
        episode_links[f"Episode {len(episode_links)+1}"] = quality_links

    return episode_links

def extract_fallback_episodes(content):
    """Fallback extraction logic for single-episode content with multiple qualities."""
    episode_links = {}
    fallback_episode_pattern = re.compile(r'<div class="mks_toggle_heading">.*?(\d+p).*?</div>.*?<a href="([^"]+)"', re.DOTALL)
    fallback_episodes = re.findall(fallback_episode_pattern, content)

    if fallback_episodes:
        episode_links["Episode 1"] = {quality: link for quality, link in fallback_episodes}

    return episode_links

# Example usage
"""
anime_data = extract_data("13940")
pprint.pprint(anime_data) 
"""
