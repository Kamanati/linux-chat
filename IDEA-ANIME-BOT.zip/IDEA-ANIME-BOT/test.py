import requests
import re
import pprint

import requests

import requests
from bs4 import BeautifulSoup

def final_bot_url(url):
    # Step 1: Fetch the webpage
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')

    # Step 2: Extract the values from the hidden input fields
    filename = soup.find('input', {'id': 'filename'})['value']
    fileurl = soup.find('input', {'id': 'fileurl'})['value']
    vkshareid = soup.find('input', {'id': 'vkshareid'})['value']
    gdmrid = soup.find('input', {'id': 'gdmrid'})['value']

    # Step 3: Make the POST request to the API
    api_url = 'https://vkshare.online/vk/vkinfo.php?action=handleVKFile'
    data = {
        'fileurl': filename,
        'filename': fileurl,
        'vkid': vkshareid,
        'gdmrid': gdmrid,
    }
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
    }
    response = requests.post(api_url, data=data, headers=headers)

    # Step 4: Process the response to get the final link
    final_link = response.text.replace('"', '')

    # Step 5: Construct the Telegram bot link
    bot_link = f'https://t.me/gdmorebot?start={final_link}'

    return bot_link

# Example usage:
url = "https://gdmirrorbot.nl/file/bmdpmjf"
final_bot_link = final_bot_url(url)
print("Final Bot Link:", final_bot_link)
