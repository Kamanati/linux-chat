import requests,sys

# Base URL for the API
base_url = "https://toonhub4u.net/wp-json/wp/v2/posts"

# Parameters for the API call
params = {
    "context": "view",       # Using "view" context
    "search": "one piece",     # Replace 'keyword' with your search term
    "page": 1,               # Optional: to specify page number
    "per_page": 10           # Optional: to limit the number of posts returned
}

# Sending a GET request to the API
response = requests.get(base_url, params=params)
import json

"""
with open('sample.json',"w") as f:
     json.dump(response.json(), f,indent=4 )
"""

# Checking if the request was successful
if response.status_code == 200:
    posts = response.json()  # Parsing the response as JSON
    for post in posts:
        print(f"Title: {post['title']['rendered']}")
        print(f"Link: {post['id']}\n")
        
else:
    print(f"Failed to retrieve posts. Status code: {response.status_code}")
