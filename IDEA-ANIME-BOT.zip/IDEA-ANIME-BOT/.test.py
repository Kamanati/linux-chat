import requests

def extract_anime_data(url):
    response = requests.get(url)
    
    if response.status_code != 200:
        return None

    data = response.json()
    
    # Extract necessary details
    title = data.get('title', {}).get('rendered', '')
    link = data.get('link', '')
    content = data.get('content', {}).get('rendered', '')
    
    # Extract download links from content
    download_links = []
    
    if 'mks_toggle_content' in content:
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(content, 'html.parser')
        toggle_divs = soup.find_all('div', class_='mks_toggle_content')
        
        for div in toggle_divs:
            quality = div.find_previous_sibling('div', class_='mks_toggle_heading').text.strip()
            link = div.find('a').get('href')
            download_links.append({'quality': quality, 'link': link})
    
    return {
        'title': title,
        'link': link,
        'download_links': download_links
    }

# Example usage:
url = "https://toonhub4u.net/wp-json/wp/v2/posts/13940"
anime_data = extract_anime_data(url)
print(anime_data)
