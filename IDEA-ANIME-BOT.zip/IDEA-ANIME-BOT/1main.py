import requests,pprint
import re

def extract_data(id):
    # Fetching the JSON data from the URL
    response = requests.get(f"https://toonhub4u.net/wp-json/wp/v2/posts/{id}")
    data = response.json()

    # Extracting the required information
    title = data["title"]["rendered"]
    excerpt = data["excerpt"]["rendered"]
    # Extracting primary image URLs
    image_url_1 = re.search(r'<a\s+href="([^"]+)"\s+target="_blank"\s+rel="noopener">', data["content"]["rendered"])
    image_url = re.search(r'src="([^"]+)"', data["content"]["rendered"])

    # If regex finds no match, we set the value to None
    image_url_1 = image_url_1.group(1) if image_url_1 else None
    image_url = image_url.group(1) if image_url else None

    # Extracting language and quality from the content
    language_match = re.search(r'Language:\s*([^<]+)', excerpt)
    quality_match = re.search(r'Quality:\s*([^<]+)', excerpt)

    language = language_match.group(1).strip() if language_match else "N/A"
    quality = quality_match.group(1).strip() if quality_match else "N/A"

    # Attempt to extract episode links using regular logic
    episode_links = extract_episodes(data["content"]["rendered"])

    # If no episodes are found, use fallback logic
    if not episode_links:
        episode_links = extract_fallback_episodes(data["content"]["rendered"])

    # Organizing the data in a structured manner
    result = {
        "img_url_1": image_url_1,
        "img_url": image_url,
        "Title": title,
        "Language": language.replace("\xa0", ' '),
        "Quality": quality.replace("\xa0", ' '),
        "Episodes": episode_links
    }

    return result

def extract_episodes(content):
    """Regular extraction logic for episodes."""
    episode_links = {}
    episode_pattern = re.compile(r'Episode\s+\d+.*?<\/p>(.*?)<hr', re.DOTALL)
    quality_pattern = re.compile(r'(\d+p)\s+–\s+<a href="([^"]+)"')

    for match in episode_pattern.finditer(content):
        episode_info = match.group(1)
        quality_links = {quality: link for quality, link in quality_pattern.findall(episode_info)}
        episode_links[f"Episode {len(episode_links)+1}"] = quality_links

    return episode_links

def extract_fallback_episodes(content):
    """Fallback extraction logic for single-episode content with multiple qualities."""
    episode_links = {}
    fallback_episode_pattern = re.compile(r'<div class="mks_toggle_heading">.*?(\d+p).*?</div>.*?<a href="([^"]+)"', re.DOTALL)
    fallback_episodes = re.findall(fallback_episode_pattern, content)
    
    if fallback_episodes:
        episode_links["Episode 1"] = {quality: link for quality, link in fallback_episodes}
    
    return episode_links

pprint.pprint(extract_data("13940"))
