import telebot
from telebot.types import ReplyKeyboardMarkup, KeyboardButton
from telebot import types
import requests
import json
import time
import random
from main import *

API_TOKEN = '7420318554:AAFazGm82OokBD-LEA3NTm38A3tEL9LeD60'
bot = telebot.TeleBot(API_TOKEN)

# Dictionaries to store search results, quality options, and selected quality for each user
user_search_results = {}
user_quality_options = {}
user_selected_quality = {}
user_img_url = {}
user_titles = {}

# Function to rewrite wp_ids.json with the latest data
def update_wp_ids():
    url = 'https://toonhub4u.net/wp-json/wp/v2/posts/'
    response = requests.get(url)
    data = response.json()
    
    # Extract only the ID and save it to wp_ids.json
    ids = [{'id': post['id']} for post in data]
    
    with open('wp_ids.json', 'w') as file:
        json.dump(ids, file, indent=4)
    
    return ids

# Function to fetch the last episode ID from wp_ids.json
def get_last_episode_id():
    with open('wp_ids.json', 'r') as file:
        ids = json.load(file)
        if ids:
            return ids[0]['id']  # The first ID is the most recent one
    return None

# Function to shorten link with GPLinks if it's the last episode
def shorten_link_if_last_episode(url, episode_id):
    last_episode_id = get_last_episode_id()
    if episode_id == last_episode_id:
        gplink_api = 'https://api.gplinks.com/api?api=5ab5ab897d4db980fb7bf0ef4736e0a6a0e577a7&url=' + url
        response = requests.get(gplink_api)
        data = response.json()
        if data['status'] == 'success':
            return data['shortenedUrl']
    return url

# Function to save search history in JSON
def save_search_data(user_id, search_query):
    search_data = {'user_id': user_id, 'search_query': search_query}
    
    with open('search_history.json', 'a') as file:
        json.dump(search_data, file, indent=4)

@bot.message_handler(commands=['start'])
def handle_start(message):
    bot.send_message(message.chat.id, "Welcome to All Anime Download bot, use /search command to search anime `/search anime name` \n\nfor example /search one piece")

# Handler for search queries
@bot.message_handler(commands=['search'])
def handle_search(message):
    user_id = message.from_user.id
    search_query = message.text.replace('/search ', '')
    
    # Save the search query
    save_search_data(user_id, search_query)
    
    # Get search results (this is where your pre-created search function would be used)
    search_results = search(search_query, page=1, per_page=10)
    
    # Store search results for the user
    user_search_results[user_id] = search_results
    
    if search_results:
        markup = ReplyKeyboardMarkup(row_width=1, resize_keyboard=True)
        for title, episode_id in search_results:
            markup.add(KeyboardButton(title))
        bot.send_message(message.chat.id, "Select an anime:", reply_markup=markup)
    else:
        bot.send_message(message.chat.id, "No results found. Please try another search.")

# Handler for selecting an anime from search results
@bot.message_handler(func=lambda message: message.text in [title for title, _ in user_search_results.get(message.from_user.id, [])])
def handle_anime_selection(message):
    user_id = message.from_user.id
    title = message.text
    search_results = user_search_results.get(user_id, [])
    episode_id = next(episode_id for t, episode_id in search_results if t == title)
    
    # Fetch anime details (using your pre-created extract_data function)
    anime_data = extract_data(episode_id)
    
    img_url = anime_data['img_url']
    title = anime_data['Title']
    languages = anime_data['Language']
    quality_options = anime_data['Episodes']
    
    # Store quality options and other details for the user
    user_quality_options[user_id] = quality_options
    user_img_url[user_id] = img_url
    user_titles[user_id] = title
    
    # Create a keyboard for selecting quality
    markup = ReplyKeyboardMarkup(row_width=1, resize_keyboard=True)
    for quality in quality_options.keys():
        markup.add(KeyboardButton(quality))
    
    # Send image with caption and quality selection
    bot.send_photo(message.chat.id, img_url, caption=f"**{title}**\n\n**Languages:** {languages}", parse_mode="Markdown", reply_markup=markup)

# Handler for selecting quality
@bot.message_handler(func=lambda message: message.text in [quality for quality in user_quality_options.get(message.from_user.id, {}).keys()])
def handle_quality_selection(message):
    user_id = message.from_user.id
    selected_quality = message.text
    
    # Store selected quality for the user
    user_selected_quality[user_id] = selected_quality
    
    # Get episode options for the selected quality
    quality_options = user_quality_options.get(user_id, {})
    episode_options = quality_options.get(selected_quality, {})
    
    # Create a keyboard of episodes
    markup = ReplyKeyboardMarkup(row_width=1, resize_keyboard=True)
    for episode in episode_options.keys():
        markup.add(KeyboardButton(episode))
    
    # Send updated message asking for episode selection
    bot.send_photo(message.chat.id, user_img_url[user_id], caption=f"**Select an episode** for **{selected_quality}** quality:", parse_mode="Markdown", reply_markup=markup)

# Handler for selecting an episode
@bot.message_handler(func=lambda message: message.text in [episode for episode in user_quality_options.get(message.from_user.id, {}).get(user_selected_quality.get(message.from_user.id, ''), {}).keys()])
def handle_episode_selection(message):
    user_id = message.from_user.id
    selected_episode = message.text
    selected_quality = user_selected_quality.get(user_id, '')
    quality_options = user_quality_options.get(user_id, {})
    episode_options = quality_options.get(selected_quality, {})
    episode_url = episode_options.get(selected_episode, '')
    
    # Shorten the link if it's the last episode
    final_url = shorten_link_if_last_episode(episode_url, int(user_id))
    new_url_ = final_bot_url(final_url)
    
    # Send the final download link
    bot.send_message(message.chat.id, f"[Click here to download {selected_episode}]({new_url_})", parse_mode="Markdown")

# Function to monitor the WordPress API periodically
def monitor_wp_api():
    while True:
        update_wp_ids()
        
        # Wait for a random time between 2 to 5 minutes before checking again
        time.sleep(random.randint(120, 300))

# Start the WordPress API monitoring in a separate thread
import threading
monitoring_thread = threading.Thread(target=monitor_wp_api)
monitoring_thread.start()

# Start the bot
bot.polling() 
