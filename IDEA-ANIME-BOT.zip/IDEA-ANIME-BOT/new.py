import telebot,psutil,logging
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from telebot import types
import requests
import json
import time
import html
import re
import random
from functools import lru_cache
from main import *
from datetime import datetime
import logging

logging.basicConfig(level=logging.ERROR, filename='bot_errors.log')

# Global handler for unhandled errors
def error_handler(exception):
    logging.error(f"Unhandled exception: {exception}")


API_TOKEN = '7420318554:AAFazGm82OokBD-LEA3NTm38A3tEL9LeD60'
bot = telebot.TeleBot(API_TOKEN)
telebot.logger.setLevel(logging.ERROR)
#admin_chat_ids = [1700631357, 6971953231]
ADMIN_FILE = 'admins.json'

PRICE_AMOUNT = 10
TITLE = "All Anime Download"
DESCRIPTION = "Running this server is getting increasingly expensive, and I need your help to keep things going. If you've enjoyed the bot's features, please consider supporting me by purchasing these items. Your support is crucial for me to continue providing updates and improving the bot with even more exciting features."
CURRENCY = "XTR"  # Telegram Stars currency

def is_user_member(user_id):
    try:
        chat_member = bot.get_chat_member("@allindiataanime", user_id)
        return chat_member.status in ['member', 'administrator', 'creator']
    except Exception as e:
        print(f"Error checking membership: {e}")
        return False

def send_verification_message(chat_id):
    markup = types.InlineKeyboardMarkup()
    btn = types.InlineKeyboardButton("Join Channel", url=f"https://t.me/allindiataanime")
    markup.add(btn)
    bot.send_message(chat_id, "Please join our channel to use the bot.", reply_markup=markup)

def save_admin_ids():
    with open(ADMIN_FILE, 'w') as f:
        json.dump(admin_chat_ids, f)

def load_admin_ids():
    global admin_chat_ids
    try:
        with open(ADMIN_FILE, 'r') as f:
            admin_chat_ids = json.load(f)
    except FileNotFoundError:
        admin_chat_ids = [1700631357, 6971953231]  # Default admin IDs if the file doesn't exist
        save_admin_ids()  # Save the default IDs if the file didn't exist

load_admin_ids()
def clean_html(text):
    # Unescape HTML entities
    text = html.unescape(text)
    
    # Remove HTML tags
    text = re.sub(r'<.*?>', '', text)
    
    return text

def update_wp_ids():
    url = 'https://toonhub4u.net/wp-json/wp/v2/posts/'
    response = requests.get(url)
    data = response.json()
    
    # Extract only the ID and save it to wp_ids.json
    ids = [{'id': post['id']} for post in data]
    
    with open('wp_ids.json', 'w') as file:
        json.dump(ids, file, indent=4)
    
    return ids

# Function to fetch the last episode ID from wp_ids.json
def get_last_episode_id(l=False):
    with open("wp_ids.json","a") as y:
          pass
    with open('wp_ids.json', 'r') as file:
        ids = json.load(file)
        if ids:
          if not l:
            return ids[0]['id']  # The first ID is the most recent one
          else:
            return ids
    return None

@lru_cache(maxsize=400)
def gp_links(url,admin=False):
    gplink_api = 'https://api.gplinks.com/api?api=5ab5ab897d4db980fb7bf0ef4736e0a6a0e577a7&url=' + url
    response = requests.get(gplink_api)
    data = response.json()
    if admin:
          return url
    if data['status'] == 'success':
        print("gplink generates succes")
        return data['shortenedUrl']
    print("gplinks failed")
    return url
# Function to shorten link with GPLinks if it's the last episode
def shorten_link_if_last_episode(url, episode_id):
    last_episode_id = get_last_episode_id(l=True)
    if episode_id in last_episode_id:
        gplink_api = 'https://api.gplinks.com/api?api=5ab5ab897d4db980fb7bf0ef4736e0a6a0e577a7&url=' + url
        response = requests.get(gplink_api)
        data = response.json()
        if data['status'] == 'success':
            return data['shortenedUrl']
    return url

# Function to save search history in JSON
def save_search_data(user_id, search_query):
    search_data = {'user_id': user_id, 'search_query': search_query}
    
    with open('search_history.json', 'a') as file:
        json.dump(search_data, file, indent=4)

def load_chat_ids():
    try:
        with open('chat_ids.json', 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        return []

# Function to save chat IDs of users and channels
def save_chat_id(chat_id):
    chat_ids = load_chat_ids()
    if chat_id not in chat_ids:
        chat_ids.append(chat_id)
        with open('chat_ids.json', 'w') as file:
            json.dump(chat_ids, file, indent=4)

# Function to broadcast message to all users and a channel
def broadcast_message(img,message):
    chat_ids = load_chat_ids()
    try:
        bot.send_photo("@allindiataanime", photo=img, caption=message, parse_mode="Markdown")
    except:
        bot.send_message("@allindiataanime", message, parse_mode="Markdown")
    finally:
        print("Final error accured 1")
    for chat_id in chat_ids:
        try:
            bot.send_photo(chat_id,img, caption=message, parse_mode="Markdown")
        except Exception as e:
            bot.send_message(chat_id, message, parse_mode="Markdown")
            print(f"Failed to send message to {chat_id}: {e}")
        finally:
            print("The finall error accured bro")

def extract_image(json_content):
    content = json_content['content']['rendered']
    a_tag_match = re.search(r'<a\s+href="([^"]+)"\s+target="_blank"\s+rel="noopener">', content)
    img_tags = re.findall(r'<img[^>]+src="([^"]+)"', content)
    if a_tag_match:
        return a_tag_match.group(1)
    elif img_tags:
        return img_tags[0]
    else:
        return None
def details(url):
  response = requests.get(url)
  response.raise_for_status()

  soup = BeautifulSoup(response.content, "html.parser")

  title = soup.find("h2", style="text-align: center;").get_text(strip=True)
  details = soup.find("p", style="text-align: center;").get_text(strip=True)

  image_tag = soup.find("img", class_="aligncenter")
  image_url = image_tag["src"] if image_tag else None

  info_dict = {
    "Title": title,
    "Details": details,
    "Image URL": image_url,
    "Info": {}
  }

  info_paragraph = image_tag.find_next("p") if image_tag else None

  if info_paragraph:
    strong_tags = info_paragraph.find_all("strong")

    for tag in strong_tags:

        span = tag.find("span")
        label = span.get_text(strip=True).replace(":", "") if span else None

        if label:
            content = tag.get_text(strip=True).replace(f"{label}:", "").strip()
        else:
            content = tag.get_text(strip=True).strip()
            label = content.split(":")[0] if ":" in content else None
            content = content.replace(label + ":", "").strip() if label else content

        if label in ["Genre", "Network", "Org. run", "Running time", "Language", "Episodes", "Subtitle", "Quality"]:
            info_dict["Info"][label] = content

  return info_dict

# Modified function to monitor the WordPress API and notify users on update
def monitor_wp_api():
    last_checked_id = get_last_episode_id()

    while True:
        ids = update_wp_ids()
        current_id = ids[0]['id']
        try:
          if current_id != last_checked_id:
            last_checked_id = current_id
            anime_data = extract_data(current_id)  # Fetch data for the new>
            title = anime_data['Title']
            try:
               img_url = anime_data['img_url_1']
            except:
               img_url = anime_data["img_url"]
            data = details(f"https://toonhub4u.net/?p={current_id}")
            info = data["Info"]
            title= data["Title"]
            response = f"Title: {title}\n\n"  # Title inside a blockq>
            response += "🔍 *Info:* \n"
            for key, value in info.items():
        # Escape the key and value for Markdown V2
              response += f" • {key}: {value}\n"
            res = response.replace("Download","")
            message = res.replace("|","")
            message += f"\n\n     || [DOWNLOAD HERE ⏳️](https://t.me/All_lang_Anime_download_bot?start=search_{current_id}) ||"

            #message = f"#New episode 📢 New episode of \n\n**{title}** \n\nis now available! Get it from the bot [here](https://t.me/All_lang_Anime_download_bot?start=search_{current_id})"

            # Broadcast the update to all users and the channel
            broadcast_message(img_url,message)
        except Exception as e :
             print(e)
             continue
        finally:
             continue
        # Wait for a random time between 2 to 5 minutes before checking aga>
        time.sleep(random.randint(20, 30))

def is_user_in_channel(user_id, channel_id):
    """
    Check if a user is a member of a specified channel.

    :param user_id: The Telegram user ID to check.
    :param channel_id: The channel's username or ID to check against.
    :return: True if the user is a member, False otherwise.
    """
    try:
        chat_member = bot.get_chat_member(channel_id, user_id)
        return chat_member.status in ['member', 'administrator', 'creator']
    except telebot.apihelper.ApiException:
        # Handle exception if user is not in the channel or other errors
        return False

with open('referrer.json', 'r') as file:
    referrer_data = json.load(file)

@bot.message_handler(commands=['start'])
def handle_start(message):
     save_chat_id(message.chat.id)
     chat_id = message.chat.id
     user_id = message.from_user.id
     args = message.text.split()
    
     if len(args) > 1:
        referrer_id = args[1]  # This captures the referral ID passed in the start link
        if args[1].startswith("search_"):
            some_id = args[1][len("search_"):]
            send_anime_(message, some_id)
            return
        if referrer_id != str(user_id):  # Prevent self-referral
            if user_id not in referrer_data:
                referrer_data[user_id] = referrer_id
                save_referrer_data()
                print(f"\033[1;32m[\033[0mINFO\033[1;32m]\033[0m {user_id} - {chat_id} -- Referer")

     if message.chat.type == "private":
      if is_user_member(message.from_user.id):
            pass
      else:
        send_verification_message(message.chat.id)
        return 0
     else:
        pass
     print(f"\033[1;32m[\033[0mINFO\033[1;32m]\033[0m {user_id} - {chat_id}")

     #if not is_user_in_channel(message.chat.id, "@allindiataanime"): bot.send_message(message.chat.id, "Join the channel to use this bot\n[join](https://t.me/allindiataanime)", parse_mode="Markdown"); return 0
     if message.chat.id in admin_chat_ids:
          bot.send_message(message.chat.id, "> welcome admin\nWelcome to All Anime Download bot, use /search commamd to search anime\n\nuse `/search`",parse_mode="MarkdownV2")
     else:
          bot.send_message(message.chat.id, "Welcome to All Anime Download bot, use /search commamd to search anime\n\nfor example `/search`",parse_mode="MarkdownV2")
     save_chat_id(message.chat.id)

feedback_records_file = 'feedback_records.json'

def send_anime_(call,episode_id):
    #episode_id = int(call.data.split('_')[1])
    bot.send_message(call.chat.id,"Please Wait While Getting The Anime....")
    bot.send_chat_action(call.chat.id, 'typing')
    # Fetch anime details (using your pre-created extract_data function)
    anime_data = extract_data(episode_id)

    title = anime_data['Title']
    quality_options = anime_data['Episodes']
    languages = anime_data['Language']

    # Get all episodes
    episodes = list(quality_options.keys())
    bot.send_chat_action(call.chat.id, 'typing')
    # Initial page index
    page = 0
    send_episode_page(call,languages ,anime_data['img_url'] ,episode_id, episodes, page, title)


@bot.message_handler(commands=['refer'])
def refer_command(message):
    
    chat_id = message.chat.id
    user_id = message.from_user.id
    print(f"\033[1;32m[\033[0mINFO\033[1;32m]\033[0m {user_id} - {chat_id} -- Used Refer")
    # Extract the user's referral link
    referral_link = f"https://t.me/{bot.get_me().username}?start={message.from_user.id}"
    
    # Create the inline keyboard buttons
    markup = InlineKeyboardMarkup()
    
    # Button to share the bot with referral link
    share_button = InlineKeyboardButton(text="🔗 Share Bot", url=f"https://t.me/share/url?url={referral_link}&text=Download%20Anime%20in%20Tamil%20Hindi%20Telugu%20Malayalam%20%2B2%20languages")
    
    # Button to message about buying/customizing the bot
    message_button = InlineKeyboardButton(text="💬 Message Me About Buying", callback_data="message_admin")
    
    # Add buttons to the markup
    markup.add(share_button)
    markup.add(message_button)
    
    # Send the referral message with buttons
    bot.send_message(
    message.chat.id,
    f"✨ Hey there! I’m pouring my heart into keeping this bot running, spending $5 a week! 💸\n"
    f"It would mean so much to me if you could share it with your friends! 🌟 Your support helps keep the dream alive! 😊\n\n"
    f"📜 Plus, you can grab the full bot code for just RS 400, or if you want something unique, I’ll customize it just for you for RS 500! Your ideas matter! ❤️\n\n"
    f"🌟 With over 2000 active users enjoying this bot, I truly appreciate your support! **If the price is too high for you, please let me know—I’m happy to discuss and find a solution!**",
    parse_mode='Markdown',
    reply_markup=markup
    )

@bot.callback_query_handler(func=lambda call: call.data == "message_admin")
def handle_message_admin(call):
    user = call.from_user
    admin_chat_ids = [1700631357, 6971953231]
    # Message sent to admin with user info
    admin_message = f"📩 Exciting news! A new request from {user.first_name} (@{user.username}):\n" \
                    f"User ID: {user.id}\nProfile: tg://user?id={user.id} (@{call.from_user.username}) \n\n" \
                    f"They're interested in buying or customizing the bot! Let's give them the best experience possible! 🌟"
    
    # Send the user's info to all admins
    for admin_id in admin_chat_ids:
        bot.send_message(admin_id, admin_message)
    
    # Confirm to the user that their request has been sent
    if call.from_user.username:
      bot.send_message(
        call.message.chat.id,
        f"✅ Thank you so much! Your request has been sent! The admin will reach out to you soon. I'm so excited to help you! 🎉\n\n"
        f"If you wish to contact the admin directly, please feel free to [click here](https://t.me/NamiKasa?text=Iam%20interested%20in%20buying%20your%20bot) ✉️ ",
        parse_mode='Markdown'
     )
    else:
      bot.send_message(
      call.message.chat.id,
      f"😔 It seems like your Telegram account is private, and the admin cannot message you. \n"
      f"Please [click here](https://t.me/NamiKasa?text=Iam%20interested%20in%20buying%20your%20bot) to message the admin. ✉️",
      parse_mode='Markdown'
    )

# Save referrer data to the file
def save_referrer_data():
    with open('referrer.json', 'w') as f:
        json.dump(referrer_data, f, indent=4)

@bot.message_handler(commands=['help'])
def handle_help(message):
    help_text = (
        "Here are the available commands:\n\n"
        "/start - Start the bot and get a welcome message.\n"
        "/search - Search for an anime.\n"
        "/latest - Get the latest(recently) anime updates.\n"
        "/feedback <your feedback> - Send feedback to the admins (limit: 2 per day).\n"
        "/status - Get the status of the bot (admins only).\n"
        "/refer - Please consider referring this bot to a friend. Your support will help ensure it can continue running for a long time"
        "/aprove_for_admin - Request to become an admin.\n"
        "/sfb <message> - Send an update to all users (admins only).\n"
        "/help - Show this help message."
    )
    bot.send_message(message.chat.id, help_text)

load_chat_ids()

def load_feedback_records():
    try:
        with open(feedback_records_file, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        return {}

# Function to save feedback records to JSON file
def save_feedback_records(records):
    with open(feedback_records_file, 'w') as file:
        json.dump(records, file)

# Load feedback records
feedback_records = load_feedback_records()

# Command to handle user feedback
@bot.message_handler(commands=['feedback'])
def handle_feedback(message):
    user_id = message.from_user.id

    # Check if user has already sent feedback today
    today = datetime.now().date()
    if user_id not in feedback_records:
        feedback_records[user_id] = {"count": 0, "date": str(today)}

    if feedback_records[user_id]["date"] == str(today) and feedback_records[user_id]["count"] >= 2:
        bot.reply_to(message, "You have reached the maximum number of feedback submissions for today.")
        return

    # Collect feedback
    feedback = message.text.replace('/feedback', '').strip()
    if not feedback:
        bot.reply_to(message, "Please provide feedback after the /feedback command.")
        return

    # Update feedback record
    if feedback_records[user_id]["date"] != str(today):
        feedback_records[user_id]["date"] = str(today)
        feedback_records[user_id]["count"] = 0

    feedback_records[user_id]["count"] += 1

    # Save feedback records
    save_feedback_records(feedback_records)

    # Send feedback to admin
    for admin_chat_id in admin_chat_ids:
        bot.send_message(admin_chat_id, f"Feedback from user {user_id}: {feedback}")

    bot.reply_to(message, "Thank you for your feedback!")

# Command for admin to send updates
@bot.message_handler(commands=['sfb'])
def handle_send_feed_back(message):
    user_id = message.from_user.id

    # Check if message sender is an admin
    if user_id not in admin_chat_ids:
        bot.reply_to(message, "You are not authorized to use this command.")
        return

    # Extract the message content
    update_message = message.text.replace('/sfb', '').strip()
    if not update_message:
        bot.reply_to(message, "Please provide the message to send after the /sfb {Message you want to send}.")
        return
    succ = 0
    user_chat_ids = load_chat_ids()
    # Send the message to all users
    for user_chat_id in user_chat_ids:
        try:
            bot.send_message(user_chat_id, update_message)
            succ += 1
        except:
             pass
    od = [1700631357, 6971953231]

    for id in od:
          bot.send_message(id,f"Total Users That sent: {succ}")
    succ = 0

    bot.reply_to(message, "Update sent to all users.")

REQUESTS_FILE = 'requests.json'
ADMIN_IDS = [1700631357, 6971953231]

def load_requests():
    try:
        with open(REQUESTS_FILE, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_requests(requests):
    with open(REQUESTS_FILE, 'w') as f:
        json.dump(requests, f)

@bot.message_handler(commands=['aprove_for_admin'])
def request_admin_approval_command(message):
    user_id = str(message.from_user.id)
    user_name = message.from_user.username or message.from_user.first_name

    requests = load_requests()
    today = datetime.now().strftime('%Y-%m-%d')

    # Check if the user has already made a request today
    if user_id in requests and requests[user_id] == today:
        bot.reply_to(message, "You've already requested admin approval today. Please try again tomorrow.")
        return

    # Update the request log
    requests[user_id] = today
    save_requests(requests)

    # Create an inline keyboard with approve and reject buttons
    keyboard = InlineKeyboardMarkup()
    approve_button = InlineKeyboardButton("Approve", callback_data=f"approve_{user_id}")
    reject_button = InlineKeyboardButton("Reject", callback_data=f"reject_{user_id}")
    keyboard.add(approve_button, reject_button)

    # Notify the specified admins only
    for admin_id in ADMIN_IDS:
        bot.send_message(admin_id, f"User {user_name} (ID: {user_id}) has requested to become an admin.", reply_markup=keyboard)

    bot.reply_to(message, "Your request has been sent to the admins for approval.")

@bot.message_handler(commands=['status'])
def status_command(message):
    user_id = message.from_user.id
    total = load_chat_ids()
    if user_id in admin_chat_ids:
        total_users = len(total)
        total_feedback = sum(record["count"] for record in feedback_records.values())
        status_message = (
            f"Total Users: {total_users}\n"
            f"Total Feedback Submitted: {total_feedback}"
        )
        bot.reply_to(message, status_message)
    else:
        bot.reply_to(message, "You are not authorized to use this command.")

@bot.message_handler(commands=['latest'])
def handle_search(message):
    #if not is_user_in_channel(message.chat.id, "@allindiataanime"): bot.send_message(message.chat.id, "Join the channel to use this bot\n[join](https://t.me/allindiataanime)", parse_mode="Markdown"); return 0
    user_id = message.from_user.id

    # Save the search query
    #save_search_data(user_id, search_query)
    bot.send_chat_action(message.chat.id, 'typing')

    search_results = search("sample",url=True)

    if search_results:
        markup = types.InlineKeyboardMarkup()
        for title, episode_id in search_results:
            markup.add(types.InlineKeyboardButton(title, callback_data=f'select_{episode_id}'))
        bot.send_message(message.chat.id, "Select an anime:", reply_markup=markup)
    else:
        bot.send_message(message.chat.id, "No results found. Please try another search.")


@bot.message_handler(commands=['search'])
def handle_search(message):
    #if not is_user_in_channel(message.chat.id, "@allindiataanime"): bot.send_mes>
    if message.chat.type == "private":
     if is_user_member(message.from_user.id):
            pass
     else:
        send_verification_message(message.chat.id)
        return 0
    else:
       pass

    user_id = message.from_user.id
    search_query = message.text.replace('/search', '')

    if not search_query:
        bot.send_message(
            message.chat.id, """
            *Usage:*
*To search for your favorite anime, use:*
`/search <Your Search Query>`

_For example:_
`/search Naruto`

_This will fetch results related to "Naruto"\._
""",parse_mode="MarkdownV2"
        )
        return
    print(f"User: \033[32m{message.chat.id}\033[0m - {search_query}")
    # Get search results (this is where your pre-created search function would be>
    bot.send_message(message.chat.id, f"Searching Anime for: || {search_query} ||",parse_mode="MarkdownV2")
    user_id = message.from_user.id
    #search_query = message.text.replace('/search ', '')
    # Save the search query
    save_search_data(user_id, search_query)
    bot.send_chat_action(message.chat.id, 'typing')
    
    # Get search results (this is where your pre-created search function would be used)
    search_results = search(search_query, page=1, per_page=50) 
    if search_results:
        markup = types.InlineKeyboardMarkup()
        for title, episode_id in search_results:
            markup.add(types.InlineKeyboardButton(title, callback_data=f'select_{episode_id}'))
        bot.send_message(message.chat.id, "Select an anime:", reply_markup=markup)
    else:
        bot.send_message(message.chat.id, "No results found. Please try another search.")
"""
@bot.callback_query_handler(func=lambda call: call.data.startswith('select_'))
def handle_anime_selection(call):
    episode_id = int(call.data.split('_')[1])

    bot.send_chat_action(call.message.chat.id, 'typing')
    
    # Fetch anime details using your pre-created extract_data function
    anime_data = extract_data(episode_id)
    
    img_url = anime_data['img_url']
    title = anime_data['Title']
    episodes = anime_data['Episodes']
    
    # Create an inline keyboard for selecting episodes only
    markup = InlineKeyboardMarkup(row_width=3)
    for episode in episodes.keys():
        markup.add(InlineKeyboardButton(episode, callback_data=f"episode_{episode_id}_{episode}"))
    
    # Send the image with caption and episode selection options
    bot.send_photo(call.message.chat.id, img_url, caption=f"**{clean_html({title})}**\n\n**Languages:** {clean_html(anime_data['Language'])}", parse_mode="Markdown", reply_markup=markup)
"""

@bot.message_handler(commands=['donate'])
def send_invoice(message):
    prices = [telebot.types.LabeledPrice(label=TITLE, amount=PRICE_AMOUNT)]
    
    bot.send_invoice(
        message.chat.id, 
        title=TITLE, 
        description=DESCRIPTION, 
        provider_token='',  # Leave empty for digital goods
        currency=CURRENCY, 
        prices=prices, 
        start_parameter='start', 
        invoice_payload='invoice_payload'
    )

# Approving the pre-checkout query
@bot.pre_checkout_query_handler(func=lambda query: True)
def pre_checkout(pre_checkout_query):
    bot.answer_pre_checkout_query(pre_checkout_query.id, ok=True)

# Handling successful payments
@bot.message_handler(content_types=['successful_payment'])
def successful_payment(message):
    print(f"Payment successful for {message.successful_payment.total_amount} {message.successful_payment.currency}")
    bot.send_message(message.chat.id, "Thank you for your purchase!")



@bot.callback_query_handler(func=lambda call: call.data.startswith('approve_') or call.data.startswith('reject_'))
def handle_admin_approval(call):
    user_id = int(call.data.split('_')[1])
    user_name = call.message.chat.username or call.message.chat.first_name
    admin_id = call.from_user.id

    # Only allow the specified admins to approve or reject
    if admin_id not in ADMIN_IDS:
        bot.answer_callback_query(call.id, "You are not authorized to approve or reject admin requests.")
        return

    if call.data.startswith('approve_'):
        if user_id not in admin_chat_ids:
            admin_chat_ids.append(user_id)
            save_admin_ids()  # Save the updated admin list to 'admins.json'
            bot.answer_callback_query(call.id, f"User {user_name} (ID: {user_id}) has been added as an admin.")
            bot.send_message(user_id, "Congratulations! You have been approved as an admin.")
        else:
            bot.answer_callback_query(call.id, f"User {user_name} (ID: {user_id}) is already an admin.")
    elif call.data.startswith('reject_'):
        bot.answer_callback_query(call.id, f"User {user_name} (ID: {user_id}) has been rejected for admin approval.")
        bot.send_message(user_id, "Your request to become an admin has been rejected.")

from math import ceil
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton

# Number of episodes per page
EPISODES_PER_PAGE = 200

# Handler for selecting quality (modified to directly show episodes)
@bot.callback_query_handler(func=lambda call: call.data.startswith('select_'))
def handle_anime_selection(call,cust=False):
    episode_id = int(call.data.split('_')[1])
    bot.send_chat_action(call.message.chat.id, 'typing')
    # Fetch anime details (using your pre-created extract_data function)
    anime_data = extract_data(episode_id)
    print("Got herw 1")
    data = details(f"https://toonhub4u.net/?p={current_id}")
    info = data["Info"]
    title= data["Title"]
    response = f"Title: {title}\n\n"  # Title inside a blockq>
    response += "🔍 *Info:* \n"
    for key, value in info.items():
        # Escape the key and value for Markdown V2
        response += f" • {key}: {value}\n"
    res = response.replace("Download","")
    title = res.replace("|","")
    print("Got here")
    #title = anime_data['Title']
    quality_options = anime_data['Episodes']
    languages = anime_data['Language']
    
    # Get all episodes
    episodes = list(quality_options.keys())
    bot.send_chat_action(call.message.chat.id, 'typing')
    # Initial page index
    page = 0
    send_episode_page(call.message,languages ,anime_data['img_url'] ,episode_id, episodes, page, title)

def send_episode_page(message, lan ,img ,episode_id, episodes, page, title):
    start = page * EPISODES_PER_PAGE
    end = start + EPISODES_PER_PAGE
    total_pages = ceil(len(episodes) / EPISODES_PER_PAGE)

    # Create a grid of episodes for the current page
    markup = InlineKeyboardMarkup(row_width=2)
    last = len(episodes)
    for episode in episodes[start:end]:
        markup.add(InlineKeyboardButton(episode, callback_data=f"episode_{episode_id}_{episode}_{last}"))

    if page == 0:
        bot.send_photo(message.chat.id, img ,caption=f"**Select an episode for {title}:**", parse_mode="Markdown", reply_markup=markup)
    else:
        bot.edit_message_reply_markup(message.chat.id, message_id=message.message_id, reply_markup=markup)

# Handler for pagination
@bot.callback_query_handler(func=lambda call: call.data.startswith('page_'))
def handle_pagination(call):
    _, episode_id, page, last = call.data.split('_')
    page = int(page)
    
    # Fetch animey details again
    anime_data = extract_data(int(episode_id))
    title = anime_data['Title']
    episodes = list(anime_data['Episodes'].keys())
    languages = anime_data['Language']

    bot.send_chat_action(call.message.chat.id, 'typing')
    send_episode_page(call.message, languages ,anime_data['img_url'] ,episode_id, episodes, page, title)

# Handler for selecting an episode
@bot.callback_query_handler(func=lambda call: call.data.startswith('episode_'))
def handle_episode_selection(call):
    _, episode_id, selected_episode, last_ep  = call.data.split('_')

    # Fetch anime details again
    anime_data = extract_data(int(episode_id))
    quality_links = anime_data['Episodes'][selected_episode]
    bot.send_chat_action(call.message.chat.id, 'typing')
    bot.send_message(call.message.chat.id, "The download link is getting read Wait Few seconds.!")
    admin = call.message.chat.id in admin_chat_ids
    sent_message = bot.send_sticker(call.message.chat.id, "CAACAgIAAxkBAAKIp2cjtXoYJVMtOSiOkYeCisOFxD82AAKJCgACcW6JS9OXXOiMKwOwNgQ")  #"CAACAgUAAxkBAAJwDmbGLgF2T1epCoSRFoypnE5kxipxAAJODwACUHsxViiDpwT4o8BhNQQ")
    if call.message.chat.id in admin_chat_ids:
          message = f"**Links for {selected_episode}:**\n"
    else:
          message = f"**Links for {selected_episode}:**\n"
    selected_ep = int(re.search(r'\d+', selected_episode).group()) if re.search(r'\d+', selected_episode) else 1
    print(last_ep, selected_ep)
    for quality, url in quality_links.items():
        bot.send_chat_action(call.message.chat.id, 'typing')
        new_url = final_bot_url(url)
        if int(last_ep) == selected_ep:
              real = gp_links(new_url,admin=admin)
        else:
              real = new_url
        bot.send_chat_action(call.message.chat.id, 'typing')
        message += f"\n **{quality}**: [Download Here]({real})\n"
        #message += f"\n[{quality}]({new_url_})\n"
    
    if "gplink" in message:
        message += f"\n⚠️ This episode Has gplinks, \nsee how to open [see here](https://t.me/makabots/4)"

    bot.delete_message(call.message.chat.id, sent_message.message_id)

    bot.send_message(call.message.chat.id, message, parse_mode="Markdown")
    bot.send_sticker(call.message.chat.id, "CAACAgUAAxkBAAJvvGbGEwxkUP6qyG9CUlEyclPUpiwRAAJ9CQACeSDZVX4JttmjyhPMNQQ")
    # Send all available quality links for the selected episode
    """links = "\n".join([f"{quality}: [Download]({final_bot_url({shorten_link_if_last_episode({url}, int(episode_id)}))})" for quality, url in quality_links.items()])
    bot.send_message(call.message.chat.id, f"**Links for {selected_episode}:**\n\n{links}", parse_mode="Markdown")
    """

"""
@bot.callback_query_handler(func=lambda call: call.data.startswith('episode_'))
def handle_episode_selection(call):
    _, episode_id, selected_episode = call.data.split('_')3
    
    bot.send_chat_action(call.message.chat.id, 'typing')
    
    # Fetch the anime data again
    anime_data = extract_data(int(episode_id))
    quality_options = anime_data['Episodes'][selected_episode]
    
    # Prepare the message with all available quality links
    message = f"**Links for {selected_episode}:**\n"
    for quality, url in quality_options.items():
        final_url = shorten_link_if_last_episode(url, int(episode_id))
        new_url_ = final_bot_url(final_url)
        message += f"Quality: {quality}\n\n[Download]({new_url_})\n\n"
    
    # Send the final message with all quality links
    bot.send_message(call.message.chat.id, message, parse_mode="Markdown")
# Function to monitor the WordPress API periodically

"""

import threading
monitoring_thread = threading.Thread(target=monitor_wp_api)
monitoring_thread.start()

# Start the bot
#bot.infinity_polling(skip_pending=True, long_polling_timeout=20, logger_level=logging.ERROR)

while True:
    try:
        bot.polling(none_stop=True)
    except KeyboardInterrupt:
        print("Bot stopped by user (CTRL + C)")
        break
    except Exception as e:
        error_handler(e)
