#!/usr/bin/env python3

import requests
from bs4 import BeautifulSoup
from lxml import html
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.markdown import Markdown
import argparse
import sys
import subprocess

g = "\033[92m"
r = "\033[31m"
res = "\033[0m"
def die(message,**kwargs):
    red = "\033[31m"
    reset = "\033[0m"
    print(f"[{red}warning{reset}] {message}",**kwargs)

def info(message, **kwargs):
    green = "\033[32m"
    r = "\033[0m"
    print(f"[{green}INFO{r}] {message}", **kwargs)

def find_name(url):
    try:
        tree = html.fromstring(url)
        name = tree.xpath('//td[text()="Name of the Student"]/following-sibling::td/text()')
        return name[0] if name else 'Name not found'
    except requests.RequestException as e:
        return f"An error occurred: {e}"

def format(data):
    formatted = ""
    for course in data['data']:
        course_name = course['course_name']
        total = course['total']
        absent = course['absent']
        percentage = course['percentage']
        credits = course['credits']

        formatted += (f"**{course_name}**\n"
                      f" - Total Classes: \033[93m{total}\033[0m\n"
                      f" - Absent: \033[91m{absent}\033[0m\n"
                      f" - Percentage: \033[92m{percentage}%\033[0m\n"
                      f" - Credits: `{credits}`\n\n")
    return formatted

def fetch(register_no, password):
    login_url = 'https://sis.kalasalingam.ac.in/login'
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
    info(f"Logging {register_no} [{r}●{res}]",end="\r")
    session = requests.Session()
    info(f"Requesting({register_no}) [{r}●{res}]",end="\r")
    response = session.get(login_url, headers=headers)
    soup = BeautifulSoup(response.text, 'html.parser')
    csrf_token = soup.find('input', {'name': '_token'})['value']
    login_data = {'register_no': register_no, 'password': password, '_token': csrf_token}
    info(f"Validating({register_no}) [{r}●{res}]",end="\r")
    response = session.post(login_url, data=login_data, headers=headers)

    if response.status_code == 200 and "Dashboard" in response.text:
        info(f'Login successful({register_no}) [{g}✔{res}]')
        grade_url = 'https://sis.kalasalingam.ac.in/attendance-details'
        grade_response = session.get(grade_url, headers=headers)
        name_url = "https://sis.kalasalingam.ac.in/"
        get_name = session.get(name_url, headers=headers)
        try:
            grade_response.raise_for_status()
            return get_name.text, grade_response.json()
        except ValueError:
            print('Response is not in JSON format')
            sys.exit(1)
            return None
    else:
        die(f'Login failed({register_no})')
        return None

def display_in_table(students_data):
    table = Table(title="Student Attendance Report")
    table.add_column("Name", justify="left", style="cyan", no_wrap=True)
    table.add_column("Course", justify="left", style="magenta")
    table.add_column("Total", justify="right", style="green")
    table.add_column("Absent", justify="right", style="red")
    table.add_column("Credits", justify="right", style="blue")
    table.add_column("Percentage", justify="right", style="blue")
    for student in students_data:
        name = student['name']
        for course in student['courses']:
            table.add_row(
                name,
                course['course_name'],
                str(course['total']),
                str(course['absent']),
                str(course['credits']),
                str(course['percentage'])
            )

    console = Console()
    console.print(table)

def main():
    parser = argparse.ArgumentParser(description="Fetch and display student attendance details.")
    parser.add_argument("-d",'--display', choices=['panel', 'table'], default='panel', help="Display type (default: panel)")
    parser.add_argument("-u",'--username', type=str, help="Username for login")
    parser.add_argument("-p",'--password', type=str, help="Password for login")
    parser.add_argument("-s",'--select', action="store_true", help="Select the Register number by fzf")
    parser.add_argument("-a",'--add', type=str, help="Add the register number to the file ")

    args = parser.parse_args()

    console = Console()
    reg_file = '/data/data/com.termux/files/home/.cache/clg/reg.txt'

    if args.add:
       with open(reg_file, 'a') as file:
           file.write(f"{args.add}\n")
       info(f"Register number {args.add} Has Added To file ")
       sys.exit(0)

    if args.select:
        try:
            reg_numbers = subprocess.check_output(['fzf'], input=open(reg_file).read(), text=True).strip().split('\n')
        except subprocess.CalledProcessError as e:
            die(f"Error selecting registration numbers: {e}")
            sys.exit(1)
    else:
        with open(reg_file, 'r') as file:
            reg_numbers = file.read().splitlines()
    # Read registration numbers from the file
    """
    with open(reg_file, 'r') as file:
        reg_numbers = file.read().splitlines()
    """

    if args.username and args.password:
       reg_numbers = [str(args.username)]

    failed = []
    all_data = []
    for reg in reg_numbers:
        if args.username and args.password:
            username = args.username
            password = args.password
        else:
            username = password = reg
        try:
           name, data = fetch(username, password)
        except TypeError as e:
           failed.append(reg)
           continue

        if data:
            student_name = find_name(name)
            formatted_data = format(data)
            student_info = {
                'reg': reg,
                'name': student_name,
                'courses': data['data']
            }
            all_data.append(student_info)
            if args.username and args.password:
                pass

    if args.display == 'table':
        display_in_table(all_data)
    else:
        # Create Markdown content
        markdown_content = ""
        for student in all_data:
            student_name = student['name']
            student_courses = format({'data': student['courses']})
            markdown_content += f"# {student_name}(\033[92m{student['reg']}\033[0m)\n\n{student_courses}\n\n---\n\n"

        # Display in a single panel
        panel = Panel(Markdown(markdown_content), title="Student Attendance Report", expand=True)
        console.print(panel)
        if len(failed) < 0:
             for i in failed:
                  info(f"Failed Number {g}{i}{res} is Failed Try with -s")

if __name__ == "__main__":
    main() 

