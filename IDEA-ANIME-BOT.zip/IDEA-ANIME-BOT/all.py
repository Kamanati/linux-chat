import requests
from bs4 import BeautifulSoup

from urllib.parse import urlencode
import urllib
"""
import argparse

def fetch_slug(filename, fileurl, vkshareid, gdmrid):
    api_url = 'https://vkshare.online/vk/vkinfo.php?action=handleVKFile'
    data = {
        'fileurl': fileurl,
        'filename': filename,
        'vkid': vkshareid,
        'gdmrid': gdmrid,
    }
    
    response = requests.post(api_url, data=urlencode(data))
    
    return response

def main():
    parser = argparse.ArgumentParser(description='Fetch data from VK Share API.')
    parser.add_argument('filename', help='The filename parameter for the API request.')
    parser.add_argument('fileurl', help='The file URL parameter for the API request.')
    parser.add_argument('vkshareid', help='The VK share ID parameter for the API request.')
    parser.add_argument('gdmrid', help='The GDMRID parameter for the API request.')

    args = parser.parse_args()
    
    result = fetch_slug(args.filename, args.fileurl, args.vkshareid, args.gdmrid)
    print(result.text)
    print(result.json)
    print(result.content)

if __name__ == '__main__':
    main()
"""

def encode_url(url):
    return urllib.parse.quote(url, safe=':/')

import time


def final_bot_url(url):
    # Step 1: Fetch the webpage
    if "gplinks" in url:
          return url

    if "toonhub" in url:
          url_ = decode_url(url)
          url = url_

    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')

    """
    # Step 2: Extract the values from the hidden input fields
    filename = soup.find('input', {'id': 'filename'})['value']
    fileurl = soup.find('input', {'id': 'fileurl'})['value']
    vkshareid = soup.find('input', {'id': 'vkshareid'})['value']
    gdmrid = soup.find('input', {'id': 'gdmrid'})['value']
    """
    # Step 3: Make the POST request to the API
    api_url = 'https://vkshare.online/vk/vkinfo.php?action=handleVKFile'
    data = {
        'fileurl': "https://www117.anzeat.pro/streamhls/159c50f4515921e837163aaf2eed3ae6/ep.8.1724254660.m3u8",
        'filename': "[Toon web] Sample 232us.mkv",
        'vkid': 399947,
        'gdmrid': "hasswusxy",
    }
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
    }
    response = requests.post(api_url, data=data, headers=headers)

    print(response.text)
    print(response.content)

    # Step 4: Process the response to get the final link
    final_link = response.text.replace('"', '')

    # Step 5: Construct the Telegram bot link
    bot_link = f'https://t.me/gdmorebot?start={final_link}'

    return bot_link

print(final_bot_url("https://snapinsta.storyy.shop/files/f450da403a1b"))
