import telebot
import json

# Initialize the bot with your token
bot = telebot.TeleBot('7420318554:AAFazGm82OokBD-LEA3NTm38A3tEL9LeD60')

def chat_id_to_username(chat_id):
    try:
        chat = bot.get_chat(chat_id)
        if chat.username:
            return f"@{chat.username}"
        else:
            return f"User with chat ID {chat_id} has no username."
    except Exception as e:
        return f"Error for chat ID {chat_id}: {str(e)}"

def convert_chat_ids_to_usernames(file_path):
    # Load the chat IDs from the JSON file
    with open(file_path, 'r') as file:
        chat_ids = json.load(file)
    
    # Loop through each chat ID and convert to username
    for chat_id in chat_ids:
        username = chat_id_to_username(chat_id)
        print(username)  # Print the username (or error message)

# Replace 'chat_ids.json' with the actual path to your JSON file
convert_chat_ids_to_usernames('chat_ids.json')
