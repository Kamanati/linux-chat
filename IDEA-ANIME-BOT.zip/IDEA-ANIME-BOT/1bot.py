import telebot
from telebot import types
import json
import os
from main import *

# Initialize the bot with your API token
API_TOKEN = '7420318554:AAFazGm82OokBD-LEA3NTm38A3tEL9LeD60'
bot = telebot.TeleBot(API_TOKEN)

user_data = {}  # Dictionary to store temporary user data
search_data_file = 'user_search_data.json'

# Load search data from file if it exists
if os.path.exists(search_data_file):
    with open(search_data_file, 'r') as file:
        search_data = json.load(file)
else:
    search_data = {}

@bot.message_handler(commands=['start'])
def start(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    search_btn = types.KeyboardButton("Search Anime")
    markup.add(search_btn)
    bot.send_message(message.chat.id, "Welcome! Type 'Search Anime' to start searching.", reply_markup=markup)

@bot.message_handler(func=lambda message: message.text == 'Search Anime')
def prompt_search(message):
    bot.send_message(message.chat.id, "Please enter the name of the anime you're searching for:")

@bot.message_handler(func=lambda message: message.text and message.text != 'Search Anime')
def handle_search(message):
    search_query = message.text  # Capture the user's search query
    search_results = search(search_query, page=1, per_page=10)  # Use the user's search query
    
    # Save search data
    user_id = str(message.chat.id)
    if user_id not in search_data:
        search_data[user_id] = {'searches': {}}
    
    if search_query in search_data[user_id]['searches']:
        search_data[user_id]['searches'][search_query] += 1
    else:
        search_data[user_id]['searches'][search_query] = 1

    with open(search_data_file, 'w') as file:
        json.dump(search_data, file, indent=4)
    
    if search_results:
        markup = types.InlineKeyboardMarkup()
        for title, anime_id in search_results:
            markup.add(types.InlineKeyboardButton(title, callback_data=f'anime_{anime_id}'))
        bot.send_message(message.chat.id, "Select an anime:", reply_markup=markup)
    else:
        bot.send_message(message.chat.id, "No results found. Please try another search.")

@bot.callback_query_handler(func=lambda call: call.data.startswith('anime_'))
def handle_anime_selection(call):
    anime_id = int(call.data.split('_')[1])
    anime_data = extract_data(anime_id)  # Call the extract_data function
    
    img_url = anime_data['img_url']
    title = anime_data['Title']
    language = anime_data['Language']

    # Store user data to handle the next steps
    user_data[call.message.chat.id] = {'anime_id': anime_id, 'anime_data': anime_data}

    markup = types.InlineKeyboardMarkup()
    
    # Dynamically create buttons for available qualities
    available_qualities = set()
    for episode in anime_data['Episodes'].values():
        available_qualities.update(episode.keys())

    for q in sorted(available_qualities):  # Sort for consistent button order
        markup.add(types.InlineKeyboardButton(q, callback_data=f'quality_{q}'))

    bot.send_photo(
        chat_id=call.message.chat.id,
        photo=img_url,
        caption=f"*{title}*\n\nLanguage: *{language}*\n\n*Select Quality:*",
        parse_mode="Markdown",
        reply_markup=markup
    )

@bot.callback_query_handler(func=lambda call: call.data.startswith('quality_'))
def handle_quality_selection(call):
    selected_quality = call.data.split('_')[1]
    user_data[call.message.chat.id]['selected_quality'] = selected_quality
    anime_data = user_data[call.message.chat.id]['anime_data']

    markup = types.InlineKeyboardMarkup(row_width=3)
    for episode, qualities in anime_data['Episodes'].items():
        if selected_quality in qualities:
            markup.add(types.InlineKeyboardButton(episode, callback_data=f'episode_{episode}'))

    bot.edit_message_caption(
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        caption=f"Selected Quality: *{selected_quality}*\n\n*Select Episode:*",
        parse_mode="Markdown",
        reply_markup=markup
    )

@bot.callback_query_handler(func=lambda call: call.data.startswith('episode_'))
def handle_episode_selection(call):
    selected_episode = call.data.split('_')[1]
    selected_quality = user_data[call.message.chat.id]['selected_quality']
    anime_data = user_data[call.message.chat.id]['anime_data']

    episode_link = anime_data['Episodes'][selected_episode].get(selected_quality)
    if episode_link:
        final_link = final_bot_url(episode_link)  # Generate the final bot link

        bot.send_message(
            chat_id=call.message.chat.id,
            text=f"[Click here to download {selected_episode} in {selected_quality}](<{final_link}>)",
            parse_mode="Markdown"
        )

    # Clean up user data after sending the final link
    user_data.pop(call.message.chat.id, None)

# Polling the bot to keep it running
bot.polling() 
