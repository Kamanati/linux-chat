import aiohttp
import asyncio
import socket
from aiohttp import TCPConnector

# Manually resolve the host to avoid DNS
class StaticResolver(aiohttp.abc.AbstractResolver):
    async def resolve(self, host, port=0, family=socket.AF_INET):
        return [{
            "hostname": host,
            "host": "103.238.230.196",  # hardcoded IP
            "port": port,
            "family": family,
            "proto": 0,
            "flags": socket.AI_NUMERICHOST,
        }]

    async def close(self): pass

async def main():
    try:
        connector = TCPConnector(resolver=StaticResolver())
        async with aiohttp.ClientSession(connector=connector) as session:
            async with session.get("https://student.kalasalingam.ac.in") as resp:
                print("Status:", resp.status)
                print(await resp.text())
    except Exception as e:
        print("Error:", e)

asyncio.run(main()) 
