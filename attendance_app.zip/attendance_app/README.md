# Student Attendance Tracker

A Flask web application for tracking, analyzing, and optimizing student attendance data.

## Features

- **Automatic Attendance Fetching**: Connect to the Kalasalingam University portal to fetch attendance data
- **Manual Entry Option**: Manually enter attendance data for analysis
- **Visual Analytics**: View attendance data through charts and graphs
- **Future Projections**: Calculate future attendance percentages based on different scenarios
- **Target Calculator**: Determine how many classes you need to attend to reach target percentages
- **Attendance Simulator**: Simulate the impact of attending or missing future classes
- **Export Options**: Export attendance data as JSON or charts
- **Course-Specific Analysis**: Detailed insights for each individual course

## Installation

1. Clone the repository:
   ```
   git clone https://github.com/username/attendance-tracker.git
   cd attendance-tracker
   ```

2. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Run the application:
   ```
   python app.py
   ```

4. Open your browser and navigate to:
   ```
   http://localhost:12000
   ```

## Usage

1. **Login**: Enter your Kalasalingam University portal credentials to fetch attendance data
2. **Manual Entry**: Alternatively, use the manual entry form to input attendance data
3. **Dashboard**: View overall attendance summary and course-specific details
4. **Course Details**: Click on a course to see detailed analysis and future projections
5. **Export**: Export your attendance data in various formats for further analysis

## Technologies Used

- **Flask**: Web framework
- **Bootstrap**: Frontend styling
- **Chart.js**: Data visualization
- **Matplotlib**: Chart generation
- **BeautifulSoup & lxml**: Web scraping
- **aiohttp**: Asynchronous HTTP requests

## Author

- **Hasan** - [Instagram: @hasanfq6](https://instagram.com/hasanfq6)

## License

This project is licensed under the MIT License - see the LICENSE file for details.