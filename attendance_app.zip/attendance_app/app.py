
#!/usr/bin/env python3

from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from flask_cors import CORS
import requests
from bs4 import BeautifulSoup
from lxml import html
import aiohttp
import asyncio
import os
import json
import secrets
from datetime import datetime
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt
import io
import base64
import numpy as np
from werkzeug.middleware.proxy_fix import ProxyFix
import socket
from aiohttp import TCPConnector

app = Flask(__name__)
CORS(app)
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
app.secret_key = secrets.token_hex(16)

# Disable SSL warnings
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Constants
LOGIN_URL = 'https://student.kalasalingam.ac.in/login'
ATTENDANCE_URL = 'https://student.kalasalingam.ac.in/attendance-details'
PROFILE_URL = 'https://student.kalasalingam.ac.in/'

# Helper functions
def info(message, **kwargs):
    print(f"[INFO] {message}", **kwargs)

def die(message, **kwargs):
    print(f"[ERROR] {message}", **kwargs)
    return None

class StaticResolver(aiohttp.abc.AbstractResolver):
    async def resolve(self, host, port=0, family=socket.AF_INET):
        return [{
            "hostname": host,
            "host": "103.238.230.196",  # hardcoded IP
            "port": port,
            "family": family,
            "proto": 0,
            "flags": socket.AI_NUMERICHOST,
        }]

    async def close(self): pass


def find_name(html_content):
    try:
        tree = html.fromstring(html_content)
        name = tree.xpath('//td[text()="Name of the Student"]/following-sibling::td/text()')
        return name[0] if name else 'Name not found'
    except Exception as e:
        return f"An error occurred: {e}"

async def fetch_attendance(register_no, password):
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
    info(f"Logging {register_no}")
    connector = TCPConnector(resolver=StaticResolver())
    async with aiohttp.ClientSession(connector=connector) as session:
        info(f"Requesting({register_no})")
        async with session.get(LOGIN_URL, headers=headers, verify_ssl=False, timeout=100) as response:
            response_text = await response.text()
            soup = BeautifulSoup(response_text, 'html.parser')
            csrf_token = soup.find('input', {'name': '_token'})['value']
            login_data = {'register_no': register_no, 'password': password, '_token': csrf_token}
            
            info(f"Validating({register_no})")
            async with session.post(LOGIN_URL, data=login_data, headers=headers, verify_ssl=False) as response:
                if response.status == 200 and "Dashboard" in await response.text():
                    info(f'Login successful({register_no})')
                    
                    async with session.get(ATTENDANCE_URL, headers=headers, verify_ssl=False) as grade_response:
                        async with session.get(PROFILE_URL, headers=headers, verify_ssl=False) as name_response:
                            try:
                                grade_response.raise_for_status()
                                return await name_response.text(), await grade_response.json()
                            except ValueError:
                                die('Response is not in JSON format')
                                return None, None
                else:
                    die(f'Login failed({register_no})')
                    return None, None

def calculate_future_attendance(total, present, future_classes):
    """Calculate future attendance percentage after attending a certain number of classes"""
    new_total = total + future_classes
    new_present = present + future_classes
    if new_total == 0:
        return 0
    return round((new_present / new_total) * 100, 2)

def calculate_classes_to_attend(total, present, target_percentage):
    """Calculate how many more classes need to be attended to reach target percentage"""
    if total == 0:
        return 0
    current_percentage = (present / total) * 100
    
    if current_percentage >= target_percentage:
        return 0
    
    # Formula: (present + x) / (total + x) = target_percentage / 100
    # Solving for x: x = (target_percentage * total - 100 * present) / (100 - target_percentage)
    classes_needed = (target_percentage * total - 100 * present) / (100 - target_percentage)
    return max(0, int(classes_needed + 0.99))  # Round up

def calculate_classes_can_miss(total, present, min_percentage):
    """Calculate how many classes can be missed while maintaining minimum percentage"""
    if total == 0:
        return 0
    current_percentage = (present / total) * 100
    
    if current_percentage < min_percentage:
        return 0
    
    # Formula: present / (total + x) = min_percentage / 100
    # Solving for x: x = (100 * present - min_percentage * total) / min_percentage
    classes_can_miss = (100 * present - min_percentage * total) / min_percentage
    return max(0, int(classes_can_miss))  # Floor value

def generate_attendance_chart(courses):
    """Generate a bar chart for attendance data"""
    course_names = [course['course_name'] for course in courses]
    percentages = [course['percentage'] for course in courses]
    
    # Truncate long course names
    short_names = [name[:20] + '...' if len(name) > 20 else name for name in course_names]
    
    plt.figure(figsize=(10, 6))
    bars = plt.bar(short_names, percentages, color='skyblue')
    
    # Add a horizontal line at 75% (common attendance requirement)
    plt.axhline(y=75, color='r', linestyle='-', alpha=0.7, label='Minimum Required (75%)')
    
    # Color bars based on attendance percentage
    for i, bar in enumerate(bars):
        if int(float(percentages[i])) < 75:
            bar.set_color('salmon')
        else:
            bar.set_color('lightgreen')
    
    plt.xlabel('Courses')
    plt.ylabel('Attendance Percentage')
    plt.title('Attendance Percentage by Course')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    plt.legend()
    
    # Save to a bytes buffer
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    plt.close()
    
    # Convert to base64 for embedding in HTML
    img_str = base64.b64encode(buffer.getvalue()).decode('utf-8')
    return f"data:image/png;base64,{img_str}"

def generate_course_chart(course):
    """Generate a pie chart for a specific course"""
    present = int(float(course['present']))
    absent = int(float(course['absent']))
    on_duty = int(float(course.get('on_duty', 0)))
    
    labels = ['Present', 'Absent', 'On Duty']
    sizes = [present, absent, on_duty]
    colors = ['lightgreen', 'salmon', 'skyblue']
    
    # Filter out zero values
    filtered_labels = [label for i, label in enumerate(labels) if sizes[i] > 0]
    filtered_sizes = [size for size in sizes if size > 0]
    filtered_colors = [colors[i] for i, size in enumerate(sizes) if size > 0]
    
    plt.figure(figsize=(8, 8))
    plt.pie(filtered_sizes, labels=filtered_labels, colors=filtered_colors, autopct='%1.1f%%', startangle=90)
    plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle
    plt.title(f"Attendance Breakdown for {course['course_name']}")
    
    # Save to a bytes buffer
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    plt.close()
    
    # Convert to base64 for embedding in HTML
    img_str = base64.b64encode(buffer.getvalue()).decode('utf-8')
    return f"data:image/png;base64,{img_str}"

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        register_no = request.form.get('register_no')
        password = request.form.get('password')
        
        if not register_no or not password:
            flash('Please provide both register number and password', 'danger')
            return redirect(url_for('login'))
        
        # Use asyncio to run the async fetch function
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        name_html, attendance_data = loop.run_until_complete(fetch_attendance(register_no, password))
        loop.close()
        
        if attendance_data:
            student_name = find_name(name_html)
            
            # Store in session
            session['register_no'] = register_no
            session['student_name'] = student_name
            session['attendance_data'] = attendance_data
            
            return redirect(url_for('dashboard'))
        else:
            flash('Login failed. Please check your credentials.', 'danger')
            return redirect(url_for('login'))
    
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'register_no' not in session:
        flash('Please login first', 'warning')
        return redirect(url_for('login'))
    
    attendance_data = session.get('attendance_data')
    student_name = session.get('student_name')
    register_no = session.get('register_no')
    
    # Generate attendance chart
    attendance_chart = generate_attendance_chart(attendance_data['data'])
    
    # Calculate additional metrics for each course
    for course in attendance_data['data']:
        total = int(float(course['total']))
        present = int(float(course['present']))
        
        # Calculate how many more classes needed to reach 75%
        course['classes_to_attend'] = calculate_classes_to_attend(total, present, 75)
        
        # Calculate how many classes can be missed while maintaining 75%
        course['classes_can_miss'] = calculate_classes_can_miss(total, present, 75)
        
        # Calculate future attendance after attending 5 more classes
        course['future_attendance_5'] = calculate_future_attendance(total, present, 5)
        
        # Calculate future attendance after attending 10 more classes
        course['future_attendance_10'] = calculate_future_attendance(total, present, 10)
    
    return render_template('dashboard.html', 
                          student_name=student_name,
                          register_no=register_no,
                          courses=attendance_data['data'],
                          attendance_chart=attendance_chart)

@app.route('/course/<int:course_index>')
def course_detail(course_index):
    if 'register_no' not in session:
        flash('Please login first', 'warning')
        return redirect(url_for('login'))
    
    attendance_data = session.get('attendance_data')
    
    if not attendance_data or course_index >= len(attendance_data['data']):
        flash('Course not found', 'danger')
        return redirect(url_for('dashboard'))
    
    course = attendance_data['data'][course_index]
    
    # Generate course-specific chart
    course_chart = generate_course_chart(course)
    
    # Calculate additional metrics
    total = course['total']
    present = course['present']
    
    # Calculate future attendance for different scenarios
    future_scenarios = []
    for classes in range(1, 21):
        future_scenarios.append({
            'classes': classes,
            'percentage': calculate_future_attendance(total, present, classes)
        })
    
    # Calculate classes needed for different target percentages
    target_scenarios = []
    for target in [75, 80, 85, 90, 95]:
        target_scenarios.append({
            'target': target,
            'classes': calculate_classes_to_attend(total, present, target)
        })
    
    return render_template('course_detail.html',
                          course=course,
                          course_chart=course_chart,
                          future_scenarios=future_scenarios,
                          target_scenarios=target_scenarios)

@app.route('/manual_entry', methods=['GET', 'POST'])
def manual_entry():
    if request.method == 'POST':
        courses = []
        course_count = int(request.form.get('course_count', 1))
        
        for i in range(course_count):
            course_name = request.form.get(f'course_name_{i}')
            course_code = request.form.get(f'course_code_{i}')
            total = int(request.form.get(f'total_{i}', 0))
            present = int(request.form.get(f'present_{i}', 0))
            credits = int(request.form.get(f'credits_{i}', 0))
            
            # Calculate derived values
            absent = total - present
            percentage = round((present / total) * 100, 2) if total > 0 else 0
            
            courses.append({
                'course_name': course_name,
                'course_code': course_code,
                'total': total,
                'present': present,
                'absent': absent,
                'percentage': percentage,
                'credits': credits,
                'on_duty': 0  # Default value
            })
        
        # Store in session
        session['student_name'] = request.form.get('student_name', 'Manual Entry')
        session['register_no'] = request.form.get('register_no', 'Manual')
        session['attendance_data'] = {'data': courses}
        
        return redirect(url_for('dashboard'))
    
    return render_template('manual_entry.html')

@app.route('/export/<export_type>')
def export_data(export_type):
    if 'register_no' not in session:
        flash('Please login first', 'warning')
        return redirect(url_for('login'))
    
    attendance_data = session.get('attendance_data')
    student_name = session.get('student_name')
    
    if export_type == 'json':
        response = jsonify({
            'student_name': student_name,
            'register_no': session.get('register_no'),
            'courses': attendance_data['data']
        })
        response.headers['Content-Disposition'] = f'attachment; filename={student_name}_attendance.json'
        return response
    
    elif export_type == 'chart':
        # Generate attendance chart
        attendance_chart = generate_attendance_chart(attendance_data['data'])
        return render_template('export_chart.html', 
                              student_name=student_name,
                              attendance_chart=attendance_chart)
    
    else:
        flash('Invalid export type', 'danger')
        return redirect(url_for('dashboard'))

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 12000))
    app.run(debug=True)
