cat > ~/.termux/termux.properties <<EOF
dns=8.8.8.8
EOF
termux-reload-settings
