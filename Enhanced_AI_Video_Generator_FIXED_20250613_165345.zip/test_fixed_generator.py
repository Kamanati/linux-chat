#!/usr/bin/env python3
"""
Test script for the fixed Enhanced Video Generator
"""

import sys
import os

def test_imports():
    """Test all imports work correctly"""
    print("🧪 Testing imports...")
    
    try:
        print("📦 Testing MoviePy import...")
        from moviepy.editor import ImageSequenceClip, AudioFileClip
        print("✅ MoviePy imported successfully")
    except ImportError as e:
        print(f"❌ MoviePy import failed: {e}")
        return False
    
    try:
        print("🤖 Testing Enhanced Video Generator import...")
        from enhanced_video_generator_fixed import EnhancedVideoGenerator
        print("✅ Enhanced Video Generator imported successfully")
    except ImportError as e:
        print(f"❌ Enhanced Video Generator import failed: {e}")
        return False
    
    try:
        print("🌐 Testing Web Interface import...")
        from enhanced_web_interface_fixed import EnhancedVideoGeneratorInterface
        print("✅ Web Interface imported successfully")
    except ImportError as e:
        print(f"❌ Web Interface import failed: {e}")
        return False
    
    return True

def test_generator():
    """Test the video generator"""
    print("\n🎬 Testing video generation...")
    
    try:
        from enhanced_video_generator_fixed import EnhancedVideoGenerator
        
        # Initialize generator
        generator = EnhancedVideoGenerator()
        print("✅ Generator initialized successfully")
        
        # Test scene planning
        prompt = "A dragon flying over mountains"
        scenes = generator.create_scene_plan(prompt, target_duration=10.0)  # Short test
        print(f"✅ Scene planning works - created {len(scenes)} scenes")
        
        # Test image generation
        if scenes:
            test_image = generator.generate_enhanced_image(scenes[0])
            print(f"✅ Image generation works - created {test_image.size} image")
        
        print("✅ All generator tests passed!")
        return True
        
    except Exception as e:
        print(f"❌ Generator test failed: {e}")
        return False

def main():
    """Run all tests"""
    print("🎬 Enhanced AI Video Generator - Test Suite")
    print("=" * 50)
    
    # Test imports
    if not test_imports():
        print("\n❌ Import tests failed!")
        return False
    
    # Test generator
    if not test_generator():
        print("\n❌ Generator tests failed!")
        return False
    
    print("\n" + "=" * 50)
    print("🎉 ALL TESTS PASSED!")
    print("✅ Enhanced AI Video Generator is ready to use!")
    print("\n🚀 To start the web interface, run:")
    print("python enhanced_web_interface_fixed.py")
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)