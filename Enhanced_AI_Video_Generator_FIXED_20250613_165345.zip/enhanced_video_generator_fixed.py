import torch
import numpy as np
import cv2
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
import os
import random
from typing import List, Tuple, Dict

# Fixed MoviePy imports for Google Colab
try:
    from moviepy.editor import ImageSequenceClip, AudioFileClip
    print("✅ MoviePy imported successfully from moviepy.editor")
except ImportError:
    try:
        from moviepy import ImageSequenceClip, AudioFileClip
        print("✅ MoviePy imported successfully from moviepy")
    except ImportError:
        print("⚠️ MoviePy import failed, trying alternative...")
        try:
            import moviepy.editor as mpy
            ImageSequenceClip = mpy.ImageSequenceClip
            AudioFileClip = mpy.AudioFileClip
            print("✅ MoviePy imported successfully via moviepy.editor")
        except Exception as e:
            print(f"❌ MoviePy import failed: {e}")
            print("Installing MoviePy...")
            import subprocess
            import sys
            subprocess.check_call([sys.executable, "-m", "pip", "install", "moviepy==1.0.3"])
            from moviepy.editor import ImageSequenceClip, AudioFileClip
            print("✅ MoviePy installed and imported successfully")

# AI model imports with error handling
try:
    from diffusers import StableDiffusionPipeline, DDIMScheduler
    DIFFUSERS_AVAILABLE = True
except ImportError:
    print("⚠️ Diffusers not available - will use fallback mode")
    DIFFUSERS_AVAILABLE = False

try:
    from transformers import pipeline as hf_pipeline
    TRANSFORMERS_AVAILABLE = True
except ImportError:
    print("⚠️ Transformers not available - will use simplified text analysis")
    TRANSFORMERS_AVAILABLE = False

import librosa
import soundfile as sf
from scipy.signal import butter, filtfilt
import matplotlib.pyplot as plt
from datetime import datetime
import math
import re
import json
from dataclasses import dataclass

@dataclass
class SceneInfo:
    description: str
    duration: float
    mood: str
    objects: List[str]
    action: str
    camera_angle: str
    lighting: str

class EnhancedVideoGenerator:
    """Enhanced AI Video Generator with perfect quality and intelligent scene understanding"""
    
    def __init__(self, device=None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        print(f"🚀 Initializing Enhanced AI Video Generator on {self.device}")
        
        # Initialize AI models
        self.setup_models()
        
        # Create output directories
        os.makedirs("outputs", exist_ok=True)
        os.makedirs("temp", exist_ok=True)
        os.makedirs("cache", exist_ok=True)
        
        # Style settings for black background, white subjects
        self.style_settings = {
            "background_color": "black",
            "subject_color": "white",
            "contrast_boost": 1.5,
            "brightness_adjust": 0.3
        }
        
    def setup_models(self):
        """Initialize all AI models with error handling"""
        print("🤖 Loading AI models...")
        
        self.text_analyzer = None
        self.scene_analyzer = None
        self.pipe = None
        
        try:
            if TRANSFORMERS_AVAILABLE:
                # Text understanding model
                print("📝 Loading text analysis model...")
                try:
                    self.text_analyzer = hf_pipeline(
                        "text-classification",
                        model="cardiffnlp/twitter-roberta-base-emotion",
                        device=0 if self.device == "cuda" else -1
                    )
                    print("✅ Text analyzer loaded")
                except Exception as e:
                    print(f"⚠️ Text analyzer failed: {e}")
                
                # Scene understanding model
                print("🎬 Loading scene understanding model...")
                try:
                    self.scene_analyzer = hf_pipeline(
                        "zero-shot-classification",
                        model="facebook/bart-large-mnli",
                        device=0 if self.device == "cuda" else -1
                    )
                    print("✅ Scene analyzer loaded")
                except Exception as e:
                    print(f"⚠️ Scene analyzer failed: {e}")
            
            if DIFFUSERS_AVAILABLE:
                # Image generation model
                print("🎨 Loading Stable Diffusion model...")
                try:
                    model_id = "runwayml/stable-diffusion-v1-5"
                    
                    self.pipe = StableDiffusionPipeline.from_pretrained(
                        model_id,
                        torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
                        safety_checker=None,
                        requires_safety_checker=False,
                        scheduler=DDIMScheduler.from_pretrained(model_id, subfolder="scheduler")
                    )
                    self.pipe = self.pipe.to(self.device)
                    
                    # Optimize for memory
                    if hasattr(self.pipe, 'enable_attention_slicing'):
                        self.pipe.enable_attention_slicing()
                    if hasattr(self.pipe, 'enable_model_cpu_offload'):
                        self.pipe.enable_model_cpu_offload()
                    
                    print("✅ Stable Diffusion loaded")
                except Exception as e:
                    print(f"⚠️ Stable Diffusion failed: {e}")
                    self.pipe = None
            
            print("✅ Model setup complete!")
            
        except Exception as e:
            print(f"⚠️ Error loading models: {e}")
            print("🔄 Using fallback mode...")
    
    def analyze_prompt(self, prompt: str) -> Dict:
        """Advanced prompt analysis using AI"""
        print(f"🔍 Analyzing prompt: '{prompt}'")
        
        analysis = {
            "mood": "neutral",
            "emotions": [],
            "objects": [],
            "actions": [],
            "scenes": [],
            "duration_hint": 60.0
        }
        
        try:
            # Emotion analysis
            if self.text_analyzer:
                emotions = self.text_analyzer(prompt)
                analysis["emotions"] = emotions
                if emotions:
                    analysis["mood"] = emotions[0]["label"].lower()
            
            # Scene classification
            if self.scene_analyzer:
                scene_labels = [
                    "action scene", "peaceful scene", "dramatic scene", 
                    "nature scene", "urban scene", "fantasy scene",
                    "horror scene", "romantic scene", "adventure scene"
                ]
                scene_result = self.scene_analyzer(prompt, scene_labels)
                analysis["scene_type"] = scene_result["labels"][0]
            
            # Extract objects and actions using regex and keywords
            analysis["objects"] = self.extract_objects(prompt)
            analysis["actions"] = self.extract_actions(prompt)
            
        except Exception as e:
            print(f"⚠️ Analysis error: {e}")
        
        return analysis
    
    def extract_objects(self, text: str) -> List[str]:
        """Extract objects/subjects from text"""
        # Common objects that work well in black/white art
        object_keywords = [
            "tree", "forest", "mountain", "dragon", "cat", "dog", "bird", "wolf",
            "lighthouse", "castle", "tower", "ship", "boat", "car", "house",
            "person", "man", "woman", "child", "knight", "warrior", "wizard",
            "flower", "rose", "sun", "moon", "star", "cloud", "rain", "snow",
            "fire", "water", "ocean", "lake", "river", "bridge", "road", "path"
        ]
        
        found_objects = []
        text_lower = text.lower()
        
        for obj in object_keywords:
            if obj in text_lower:
                found_objects.append(obj)
        
        return found_objects
    
    def extract_actions(self, text: str) -> List[str]:
        """Extract actions/verbs from text"""
        action_keywords = [
            "flying", "walking", "running", "swimming", "dancing", "fighting",
            "growing", "falling", "rising", "moving", "jumping", "climbing",
            "sailing", "driving", "riding", "standing", "sitting", "sleeping",
            "eating", "drinking", "singing", "playing", "working", "reading"
        ]
        
        found_actions = []
        text_lower = text.lower()
        
        for action in action_keywords:
            if action in text_lower:
                found_actions.append(action)
        
        return found_actions
    
    def create_scene_plan(self, prompt: str, target_duration: float = 60.0) -> List[SceneInfo]:
        """Create intelligent scene plan for 60-second video"""
        analysis = self.analyze_prompt(prompt)
        
        # Determine number of scenes based on content complexity
        base_scenes = 8  # For 60 seconds
        scene_duration = target_duration / base_scenes
        
        scenes = []
        
        # Parse prompt for scene transitions
        if " then " in prompt.lower():
            parts = prompt.lower().split(" then ")
            base_scenes = len(parts) * 2  # Expand each part
            scene_duration = target_duration / base_scenes
        elif ". " in prompt:
            parts = prompt.split(". ")
            base_scenes = len(parts) * 2
            scene_duration = target_duration / base_scenes
        
        # Generate scene variations
        base_prompt = prompt.strip()
        
        scene_templates = [
            ("Establishing shot", "wide shot of {}", "establishing"),
            ("Close-up", "close up detailed view of {}", "intimate"),
            ("Action shot", "dynamic action scene of {}", "energetic"),
            ("Artistic view", "artistic stylized view of {}", "artistic"),
            ("Dramatic angle", "dramatic low angle view of {}", "dramatic"),
            ("Atmospheric", "atmospheric moody scene of {}", "moody"),
            ("Detail focus", "detailed focus on {}", "focused"),
            ("Final shot", "cinematic final shot of {}", "conclusive")
        ]
        
        for i, (name, template, mood) in enumerate(scene_templates):
            if i >= base_scenes:
                break
                
            scene_desc = template.format(base_prompt)
            
            scene = SceneInfo(
                description=scene_desc,
                duration=scene_duration,
                mood=mood,
                objects=analysis["objects"],
                action=analysis["actions"][0] if analysis["actions"] else "static",
                camera_angle=name.lower(),
                lighting="dramatic"
            )
            scenes.append(scene)
        
        print(f"📋 Created {len(scenes)} scenes for {target_duration}s video")
        return scenes
    
    def generate_enhanced_image(self, scene: SceneInfo) -> Image.Image:
        """Generate high-quality image with perfect black/white style"""
        
        # Enhanced prompt for black background, white subjects
        enhanced_prompt = f"""
        {scene.description}, 
        black background, white subjects, high contrast, 
        minimalist, clean lines, dramatic lighting,
        black and white art, ink drawing style,
        professional photography, studio lighting,
        {scene.mood} mood, {scene.camera_angle} angle
        """
        
        negative_prompt = """
        color, colorful, rainbow, bright colors, 
        low quality, blurry, noisy, distorted,
        text, watermark, signature, frame, border
        """
        
        if self.pipe is None:
            return self.create_fallback_image(scene)
        
        try:
            print(f"🎨 Generating: {scene.description[:50]}...")
            
            with torch.no_grad():
                result = self.pipe(
                    enhanced_prompt,
                    negative_prompt=negative_prompt,
                    num_inference_steps=30,  # Higher quality
                    guidance_scale=8.0,      # Strong prompt adherence
                    width=768,               # Higher resolution
                    height=768,
                    generator=torch.Generator(device=self.device).manual_seed(42)
                )
                image = result.images[0]
            
            # Apply perfect black/white styling
            image = self.apply_perfect_bw_style(image)
            return image
            
        except Exception as e:
            print(f"⚠️ Generation error: {e}")
            return self.create_fallback_image(scene)
    
    def apply_perfect_bw_style(self, image: Image.Image) -> Image.Image:
        """Apply perfect black background, white subject styling"""
        
        # Convert to grayscale first
        gray = image.convert('L')
        
        # Convert to numpy for processing
        img_array = np.array(gray)
        
        # Enhance contrast dramatically
        img_array = cv2.equalizeHist(img_array)
        
        # Apply adaptive threshold for clean black/white
        img_array = cv2.adaptiveThreshold(
            img_array, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
            cv2.THRESH_BINARY, 11, 2
        )
        
        # Invert if needed to ensure black background
        if np.mean(img_array) > 127:  # If background is white
            img_array = 255 - img_array
        
        # Clean up noise
        kernel = np.ones((2,2), np.uint8)
        img_array = cv2.morphologyEx(img_array, cv2.MORPH_CLOSE, kernel)
        img_array = cv2.morphologyEx(img_array, cv2.MORPH_OPEN, kernel)
        
        # Convert back to PIL
        result = Image.fromarray(img_array).convert('RGB')
        
        # Final enhancement
        enhancer = ImageEnhance.Contrast(result)
        result = enhancer.enhance(1.8)
        
        return result
    
    def create_fallback_image(self, scene: SceneInfo) -> Image.Image:
        """Create high-quality fallback image"""
        img = Image.new('RGB', (768, 768), color='black')
        draw = ImageDraw.Draw(img)
        
        # Use larger font
        try:
            font_large = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 48)
            font_medium = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 32)
        except:
            try:
                # Try alternative font paths for different systems
                font_large = ImageFont.truetype("arial.ttf", 48)
                font_medium = ImageFont.truetype("arial.ttf", 32)
            except:
                font_large = ImageFont.load_default()
                font_medium = ImageFont.load_default()
        
        # Draw based on scene objects
        if scene.objects:
            for obj in scene.objects[:3]:  # Max 3 objects
                if obj in ['tree', 'forest']:
                    self._draw_enhanced_tree(draw, img.size)
                elif obj in ['dragon', 'creature']:
                    self._draw_enhanced_dragon(draw, img.size)
                elif obj in ['mountain', 'hill']:
                    self._draw_enhanced_mountains(draw, img.size)
                elif obj in ['cat', 'animal']:
                    self._draw_enhanced_cat(draw, img.size)
                elif obj in ['lighthouse', 'tower']:
                    self._draw_enhanced_lighthouse(draw, img.size)
                elif obj in ['ocean', 'water']:
                    self._draw_enhanced_ocean(draw, img.size)
        else:
            self._draw_enhanced_abstract(draw, img.size, scene.description)
        
        # Add subtle text
        self._add_enhanced_text(draw, scene.description, font_medium, img.size)
        
        return img
    
    def _draw_enhanced_tree(self, draw, size):
        """Draw enhanced tree with more detail"""
        w, h = size
        trunk_x = w // 2
        trunk_bottom = h - 100
        trunk_top = h - 400
        
        # Main trunk with texture
        for i in range(5):
            offset = random.randint(-3, 3)
            draw.rectangle([trunk_x - 25 + offset, trunk_top, trunk_x + 25 + offset, trunk_bottom], fill='white')
        
        # Complex branch system
        for level in range(6):
            branch_y = trunk_top + level * 50
            branch_length = 80 - level * 10
            
            # Multiple branches per level
            for branch in range(3):
                angle_offset = (branch - 1) * 30
                end_x = trunk_x + branch_length * math.cos(math.radians(angle_offset))
                end_y = branch_y - 40
                
                draw.line([trunk_x, branch_y, end_x, end_y], fill='white', width=5)
                
                # Sub-branches
                for sub in range(2):
                    sub_end_x = end_x + 30 * math.cos(math.radians(angle_offset + sub * 45))
                    sub_end_y = end_y - 20
                    draw.line([end_x, end_y, sub_end_x, sub_end_y], fill='white', width=3)
        
        # Detailed foliage
        for i in range(20):
            x = trunk_x + random.randint(-120, 120)
            y = trunk_top + random.randint(-100, 100)
            r = random.randint(10, 30)
            draw.ellipse([x-r, y-r, x+r, y+r], outline='white', width=2)
    
    def _draw_enhanced_dragon(self, draw, size):
        """Draw enhanced dragon with more detail"""
        w, h = size
        
        # Body segments for more realistic look
        body_segments = [
            (w//2 - 60, h//2, 80, 40),
            (w//2 - 20, h//2 - 10, 100, 35),
            (w//2 + 40, h//2 - 20, 70, 30)
        ]
        
        for x, y, width, height in body_segments:
            draw.ellipse([x - width//2, y - height//2, x + width//2, y + height//2], fill='white')
        
        # Detailed head
        head_x, head_y = w//2 + 80, h//2 - 30
        draw.ellipse([head_x - 40, head_y - 30, head_x + 40, head_y + 30], fill='white')
        
        # Eyes
        draw.ellipse([head_x - 15, head_y - 10, head_x - 5, head_y], fill='black')
        draw.ellipse([head_x + 5, head_y - 10, head_x + 15, head_y], fill='black')
        
        # Complex wing structure
        wing_points = [
            (w//2 - 40, h//2 - 20),
            (w//2 - 120, h//2 - 100),
            (w//2 - 80, h//2 - 140),
            (w//2 - 20, h//2 - 120),
            (w//2 + 20, h//2 - 80)
        ]
        draw.polygon(wing_points, fill='white')
        
        # Wing details
        for i in range(3):
            start_x = w//2 - 40 + i * 20
            start_y = h//2 - 20
            end_x = w//2 - 100 + i * 15
            end_y = h//2 - 100
            draw.line([start_x, start_y, end_x, end_y], fill='black', width=2)
        
        # Detailed tail
        tail_segments = [
            (w//2 - 80, h//2 + 10),
            (w//2 - 140, h//2 - 10),
            (w//2 - 180, h//2 + 20),
            (w//2 - 200, h//2 + 40)
        ]
        
        for i in range(len(tail_segments) - 1):
            x1, y1 = tail_segments[i]
            x2, y2 = tail_segments[i + 1]
            width = 20 - i * 3
            draw.ellipse([x1 - width, y1 - width//2, x1 + width, y1 + width//2], fill='white')
    
    def _draw_enhanced_mountains(self, draw, size):
        """Draw enhanced mountain range"""
        w, h = size
        
        # Multiple mountain layers for depth
        mountain_layers = [
            # Background mountains
            [(0, h-150), (w//6, h-280), (w//3, h-320), (w//2, h-290), (2*w//3, h-350), (5*w//6, h-280), (w, h-200)],
            # Foreground mountains
            [(0, h-100), (w//5, h-250), (2*w//5, h-400), (3*w//5, h-380), (4*w//5, h-300), (w, h-150)]
        ]
        
        for layer_idx, peaks in enumerate(mountain_layers):
            # Create mountain silhouette
            mountain_points = [(0, h)]
            mountain_points.extend(peaks)
            mountain_points.append((w, h))
            
            # Fill with white, but make background layer slightly transparent
            if layer_idx == 0:
                # Background layer - draw outline only
                for i in range(len(peaks) - 1):
                    draw.line([peaks[i], peaks[i+1]], fill='white', width=3)
            else:
                # Foreground layer - fill solid
                draw.polygon(mountain_points, fill='white')
        
        # Add mountain details
        for peak_x, peak_y in mountain_layers[1][1:-1]:  # Skip first and last points
            # Snow caps
            cap_size = 20
            draw.polygon([
                (peak_x - cap_size, peak_y + cap_size),
                (peak_x, peak_y),
                (peak_x + cap_size, peak_y + cap_size)
            ], fill='white')
            
            # Mountain ridges
            for ridge in range(3):
                ridge_start_x = peak_x - 40 + ridge * 20
                ridge_start_y = peak_y + 30 + ridge * 15
                ridge_end_x = ridge_start_x + 60
                ridge_end_y = ridge_start_y + 40
                draw.line([ridge_start_x, ridge_start_y, ridge_end_x, ridge_end_y], fill='white', width=2)
    
    def _draw_enhanced_cat(self, draw, size):
        """Draw enhanced cat with more detail"""
        w, h = size
        cat_x, cat_y = w // 2, h // 2
        
        # Body with more realistic proportions
        draw.ellipse([cat_x - 60, cat_y - 20, cat_x + 60, cat_y + 25], fill='white')
        
        # Head
        draw.ellipse([cat_x + 45, cat_y - 35, cat_x + 95, cat_y + 15], fill='white')
        
        # Ears with inner detail
        ear1 = [(cat_x + 50, cat_y - 35), (cat_x + 60, cat_y - 55), (cat_x + 70, cat_y - 35)]
        ear2 = [(cat_x + 70, cat_y - 35), (cat_x + 80, cat_y - 55), (cat_x + 90, cat_y - 35)]
        draw.polygon(ear1, fill='white')
        draw.polygon(ear2, fill='white')
        
        # Inner ears
        draw.polygon([(cat_x + 55, cat_y - 30), (cat_x + 60, cat_y - 45), (cat_x + 65, cat_y - 30)], fill='black')
        draw.polygon([(cat_x + 75, cat_y - 30), (cat_x + 80, cat_y - 45), (cat_x + 85, cat_y - 30)], fill='black')
        
        # Eyes
        draw.ellipse([cat_x + 55, cat_y - 20, cat_x + 65, cat_y - 10], fill='black')
        draw.ellipse([cat_x + 75, cat_y - 20, cat_x + 85, cat_y - 10], fill='black')
        
        # Nose
        draw.polygon([(cat_x + 68, cat_y - 5), (cat_x + 72, cat_y - 5), (cat_x + 70, cat_y)], fill='black')
        
        # Whiskers
        for whisker in range(3):
            y_offset = (whisker - 1) * 3
            # Left whiskers
            draw.line([cat_x + 45, cat_y - 10 + y_offset, cat_x + 25, cat_y - 15 + y_offset], fill='white', width=1)
            # Right whiskers
            draw.line([cat_x + 95, cat_y - 10 + y_offset, cat_x + 115, cat_y - 15 + y_offset], fill='white', width=1)
        
        # Legs
        leg_positions = [(cat_x - 30, cat_y + 25), (cat_x - 10, cat_y + 25), (cat_x + 10, cat_y + 25), (cat_x + 30, cat_y + 25)]
        for leg_x, leg_y in leg_positions:
            draw.ellipse([leg_x - 8, leg_y, leg_x + 8, leg_y + 40], fill='white')
        
        # Tail with curve
        tail_points = []
        for i in range(20):
            t = i / 19.0
            tail_x = cat_x - 60 + t * (-80)
            tail_y = cat_y + 10 + 30 * math.sin(t * math.pi)
            tail_points.extend([tail_x, tail_y])
        
        if len(tail_points) >= 4:
            draw.line(tail_points, fill='white', width=12)
    
    def _draw_enhanced_lighthouse(self, draw, size):
        """Draw enhanced lighthouse with more detail"""
        w, h = size
        lighthouse_x = w // 2
        
        # Base structure
        base_width = 60
        top_width = 40
        height = 300
        
        # Tower with perspective
        tower_points = [
            (lighthouse_x - base_width//2, h - 80),
            (lighthouse_x - top_width//2, h - 80 - height),
            (lighthouse_x + top_width//2, h - 80 - height),
            (lighthouse_x + base_width//2, h - 80)
        ]
        draw.polygon(tower_points, fill='white')
        
        # Horizontal stripes
        for stripe in range(6):
            stripe_y = h - 120 - stripe * 40
            stripe_width = base_width - stripe * 3
            draw.rectangle([
                lighthouse_x - stripe_width//2, stripe_y - 10,
                lighthouse_x + stripe_width//2, stripe_y + 10
            ], fill='black')
        
        # Light house top structure
        top_y = h - 80 - height
        draw.ellipse([lighthouse_x - 35, top_y - 40, lighthouse_x + 35, top_y], fill='white')
        
        # Light rays with varying intensity
        ray_angles = [0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330]
        for angle in ray_angles:
            ray_length = 150 if angle % 60 == 0 else 100  # Stronger rays every 60 degrees
            end_x = lighthouse_x + ray_length * math.cos(math.radians(angle))
            end_y = top_y - 20 + ray_length * math.sin(math.radians(angle))
            width = 4 if angle % 60 == 0 else 2
            draw.line([lighthouse_x, top_y - 20, end_x, end_y], fill='white', width=width)
        
        # Base platform
        draw.ellipse([lighthouse_x - 80, h - 100, lighthouse_x + 80, h - 60], fill='white')
        
        # Rocks around base
        for rock in range(8):
            rock_angle = rock * 45
            rock_distance = 120 + random.randint(-20, 20)
            rock_x = lighthouse_x + rock_distance * math.cos(math.radians(rock_angle))
            rock_y = h - 80 + rock_distance * math.sin(math.radians(rock_angle)) * 0.3
            rock_size = random.randint(10, 25)
            draw.ellipse([rock_x - rock_size, rock_y - rock_size//2, 
                         rock_x + rock_size, rock_y + rock_size//2], fill='white')
    
    def _draw_enhanced_ocean(self, draw, size):
        """Draw enhanced ocean with detailed waves"""
        w, h = size
        
        # Multiple wave layers for depth
        wave_layers = [
            {"y_start": h//2, "amplitude": 15, "frequency": 0.02, "width": 3},
            {"y_start": h//2 + 40, "amplitude": 20, "frequency": 0.015, "width": 4},
            {"y_start": h//2 + 80, "amplitude": 25, "frequency": 0.01, "width": 5},
            {"y_start": h//2 + 120, "amplitude": 30, "frequency": 0.008, "width": 6}
        ]
        
        for layer in wave_layers:
            wave_points = []
            for x in range(0, w, 5):
                y_offset = layer["amplitude"] * math.sin(x * layer["frequency"])
                wave_y = layer["y_start"] + y_offset
                wave_points.extend([x, wave_y])
            
            if len(wave_points) >= 4:
                draw.line(wave_points, fill='white', width=layer["width"])
        
        # Wave foam details
        for foam in range(15):
            foam_x = random.randint(0, w)
            foam_y = random.randint(h//2, h - 50)
            foam_size = random.randint(5, 15)
            
            # Create foam bubble effect
            for bubble in range(3):
                bubble_x = foam_x + random.randint(-foam_size, foam_size)
                bubble_y = foam_y + random.randint(-foam_size//2, foam_size//2)
                bubble_size = random.randint(2, foam_size//2)
                draw.ellipse([bubble_x - bubble_size, bubble_y - bubble_size,
                             bubble_x + bubble_size, bubble_y + bubble_size], fill='white')
        
        # Horizon line
        draw.line([0, h//2 - 50, w, h//2 - 50], fill='white', width=2)
    
    def _draw_enhanced_abstract(self, draw, size, description):
        """Draw enhanced abstract art based on description"""
        w, h = size
        
        # Create flowing organic shapes based on description hash
        desc_hash = hash(description)
        random.seed(desc_hash)
        
        # Generate flowing curves
        for curve in range(8):
            points = []
            start_x = random.randint(0, w)
            start_y = random.randint(0, h)
            
            current_x, current_y = start_x, start_y
            
            for point in range(25):
                # Create smooth flowing movement
                angle = point * 0.3 + curve * 0.8
                distance = 20 + 10 * math.sin(point * 0.2)
                
                current_x += distance * math.cos(angle)
                current_y += distance * math.sin(angle)
                
                # Keep within bounds
                current_x = max(0, min(w, current_x))
                current_y = max(0, min(h, current_y))
                
                points.extend([current_x, current_y])
            
            if len(points) >= 4:
                width = random.randint(2, 8)
                draw.line(points, fill='white', width=width)
        
        # Add geometric elements
        for geo in range(5):
            center_x = random.randint(w//4, 3*w//4)
            center_y = random.randint(h//4, 3*h//4)
            size = random.randint(30, 80)
            
            if geo % 2 == 0:
                # Circle
                draw.ellipse([center_x - size, center_y - size,
                             center_x + size, center_y + size], outline='white', width=3)
            else:
                # Rectangle
                draw.rectangle([center_x - size, center_y - size//2,
                               center_x + size, center_y + size//2], outline='white', width=3)
    
    def _add_enhanced_text(self, draw, text, font, size):
        """Add enhanced text overlay"""
        w, h = size
        
        # Extract key words
        words = text.split()[:2]  # First 2 words
        text_to_show = ' '.join(words).upper()
        
        # Calculate text position
        try:
            bbox = draw.textbbox((0, 0), text_to_show, font=font)
            text_width = bbox[2] - bbox[0]
            text_height = bbox[3] - bbox[1]
        except:
            # Fallback for older PIL versions
            text_width, text_height = draw.textsize(text_to_show, font=font)
        
        text_x = (w - text_width) // 2
        text_y = h - 80
        
        # Draw text with multiple outlines for better visibility
        outline_offsets = [(-2, -2), (-2, 2), (2, -2), (2, 2), (-1, 0), (1, 0), (0, -1), (0, 1)]
        
        for dx, dy in outline_offsets:
            draw.text((text_x + dx, text_y + dy), text_to_show, fill='black', font=font)
        
        draw.text((text_x, text_y), text_to_show, fill='white', font=font)
    
    def create_smooth_transitions(self, img1: Image.Image, img2: Image.Image, num_frames: int = 15) -> List[Image.Image]:
        """Create ultra-smooth transitions with advanced blending"""
        frames = []
        
        if num_frames <= 1:
            return [img1]
        
        arr1 = np.array(img1)
        arr2 = np.array(img2)
        
        for i in range(num_frames):
            alpha = i / (num_frames - 1)
            
            # Use smooth easing function
            smooth_alpha = self.smooth_step(alpha)
            
            # Advanced blending
            blended = (1 - smooth_alpha) * arr1 + smooth_alpha * arr2
            
            # Add artistic transition effects
            if 0.2 < alpha < 0.8:
                # Add flowing transition effect
                flow_intensity = math.sin(alpha * math.pi) * 20
                noise = np.random.normal(0, flow_intensity, blended.shape)
                blended = np.clip(blended + noise, 0, 255)
            
            frame = Image.fromarray(blended.astype(np.uint8))
            frames.append(frame)
        
        return frames
    
    def smooth_step(self, x):
        """Smooth step function for easing"""
        return x * x * (3 - 2 * x)
    
    def generate_enhanced_audio(self, prompt: str, scenes: List[SceneInfo], duration: float) -> str:
        """Generate enhanced audio with scene-aware composition"""
        sample_rate = 44100
        t = np.linspace(0, duration, int(sample_rate * duration))
        
        # Analyze overall mood
        prompt_lower = prompt.lower()
        
        # Base frequency based on mood
        if any(word in prompt_lower for word in ['calm', 'peaceful', 'serene', 'quiet']):
            base_freq = 220  # A3
            harmony_freqs = [330, 440]  # E4, A4
            volume = 0.15
        elif any(word in prompt_lower for word in ['exciting', 'fast', 'action', 'dynamic']):
            base_freq = 440  # A4
            harmony_freqs = [660, 880]  # E5, A5
            volume = 0.25
        elif any(word in prompt_lower for word in ['dark', 'mysterious', 'spooky', 'gothic']):
            base_freq = 110  # A2
            harmony_freqs = [165, 220]  # E3, A3
            volume = 0.2
        elif any(word in prompt_lower for word in ['epic', 'dramatic', 'powerful']):
            base_freq = 330  # E4
            harmony_freqs = [440, 660]  # A4, E5
            volume = 0.3
        else:
            base_freq = 330  # E4
            harmony_freqs = [440, 550]  # A4, C#5
            volume = 0.2
        
        # Create layered audio
        audio = np.zeros_like(t)
        
        # Base drone
        audio += volume * np.sin(2 * np.pi * base_freq * t)
        
        # Harmonics
        for i, freq in enumerate(harmony_freqs):
            harmonic_volume = volume * (0.5 ** (i + 1))
            audio += harmonic_volume * np.sin(2 * np.pi * freq * t)
        
        # Add scene-based variations
        scene_duration = duration / len(scenes)
        for i, scene in enumerate(scenes):
            start_time = i * scene_duration
            end_time = (i + 1) * scene_duration
            
            start_idx = int(start_time * sample_rate)
            end_idx = int(end_time * sample_rate)
            
            if end_idx > len(audio):
                end_idx = len(audio)
            
            # Scene-specific modulation
            scene_t = t[start_idx:end_idx]
            if scene.mood == "dramatic":
                modulation = 0.1 * np.sin(2 * np.pi * 2 * scene_t)  # 2 Hz modulation
            elif scene.mood == "energetic":
                modulation = 0.15 * np.sin(2 * np.pi * 4 * scene_t)  # 4 Hz modulation
            else:
                modulation = 0.05 * np.sin(2 * np.pi * 0.5 * scene_t)  # 0.5 Hz modulation
            
            audio[start_idx:end_idx] += modulation
        
        # Add ambient texture
        ambient_noise = 0.03 * np.random.normal(0, 1, len(audio))
        
        # Apply low-pass filter to ambient noise
        b, a = butter(4, 0.05)
        ambient_noise = filtfilt(b, a, ambient_noise)
        
        audio += ambient_noise
        
        # Add reverb effect
        reverb_delay = int(0.1 * sample_rate)  # 100ms delay
        reverb_audio = np.zeros_like(audio)
        reverb_audio[reverb_delay:] = audio[:-reverb_delay] * 0.3
        audio += reverb_audio
        
        # Final processing
        b, a = butter(4, 0.8)  # Low-pass filter
        audio = filtfilt(b, a, audio)
        
        # Normalize with soft limiting
        max_val = np.max(np.abs(audio))
        if max_val > 0:
            audio = audio / max_val * 0.8
        
        # Apply fade in/out
        fade_samples = int(0.5 * sample_rate)  # 0.5 second fade
        audio[:fade_samples] *= np.linspace(0, 1, fade_samples)
        audio[-fade_samples:] *= np.linspace(1, 0, fade_samples)
        
        # Save audio file
        audio_path = f"temp/enhanced_audio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.wav"
        sf.write(audio_path, audio, sample_rate)
        
        return audio_path
    
    def create_60_second_video(self, prompt: str, fps: int = 24) -> str:
        """Create high-quality 60-second video"""
        print(f"🎬 Creating 60-second video for: '{prompt}'")
        
        # Create intelligent scene plan
        scenes = self.create_scene_plan(prompt, target_duration=60.0)
        
        all_frames = []
        
        # Generate high-quality images for each scene
        scene_images = []
        for i, scene in enumerate(scenes):
            print(f"🎨 Generating scene {i+1}/{len(scenes)}: {scene.description[:50]}...")
            img = self.generate_enhanced_image(scene)
            scene_images.append(img)
        
        # Create smooth animation with more frames
        frames_per_scene = int(fps * scene.duration)
        transition_frames = max(5, frames_per_scene // 6)  # Longer transitions
        
        for i, (img, scene) in enumerate(zip(scene_images, scenes)):
            # Add frames for current scene with subtle movement
            scene_frames = self.create_scene_movement(img, frames_per_scene - transition_frames, scene)
            all_frames.extend(scene_frames)
            
            # Add smooth transition to next scene
            if i < len(scene_images) - 1:
                transition = self.create_smooth_transitions(
                    img, scene_images[i + 1], transition_frames
                )
                all_frames.extend(transition)
        
        print(f"🎞️ Generated {len(all_frames)} total frames")
        
        # Save frames
        frame_paths = []
        for i, frame in enumerate(all_frames):
            frame_path = f"temp/frame_{i:06d}.png"
            frame.save(frame_path, quality=95)
            frame_paths.append(frame_path)
        
        # Create video
        video_duration = len(all_frames) / fps
        print(f"⏱️ Video duration: {video_duration:.2f} seconds")
        
        # Generate enhanced audio
        audio_path = self.generate_enhanced_audio(prompt, scenes, video_duration)
        
        # Combine into final video
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_path = f"outputs/enhanced_video_{timestamp}.mp4"
        
        try:
            # Create video clip
            clip = ImageSequenceClip(frame_paths, fps=fps)
            
            # Add audio
            audio_clip = AudioFileClip(audio_path)
            if audio_clip.duration > clip.duration:
                audio_clip = audio_clip.subclipped(0, clip.duration)
            
            final_clip = clip.with_audio(audio_clip)
            
            # Write high-quality video
            final_clip.write_videofile(
                output_path,
                codec='libx264',
                audio_codec='aac',
                bitrate='8000k',  # High bitrate for quality
                temp_audiofile='temp/temp_audio.m4a',
                remove_temp=True
            )
            
            print(f"✅ Enhanced video saved to: {output_path}")
            
            # Cleanup
            for frame_path in frame_paths:
                if os.path.exists(frame_path):
                    os.remove(frame_path)
            if os.path.exists(audio_path):
                os.remove(audio_path)
            
            return output_path
            
        except Exception as e:
            print(f"❌ Error creating video: {e}")
            return None
    
    def create_scene_movement(self, image: Image.Image, num_frames: int, scene: SceneInfo) -> List[Image.Image]:
        """Create subtle movement within a scene"""
        frames = []
        
        for i in range(num_frames):
            # Create subtle movement based on scene type
            if scene.action in ['flying', 'moving']:
                # Slight horizontal movement
                offset_x = int(5 * math.sin(i * 0.1))
                offset_y = int(2 * math.cos(i * 0.1))
            elif scene.action in ['growing', 'rising']:
                # Slight scaling
                scale_factor = 1.0 + 0.02 * math.sin(i * 0.05)
                new_size = (int(image.width * scale_factor), int(image.height * scale_factor))
                temp_img = image.resize(new_size, Image.Resampling.LANCZOS)
                # Center crop back to original size
                left = (temp_img.width - image.width) // 2
                top = (temp_img.height - image.height) // 2
                image_frame = temp_img.crop((left, top, left + image.width, top + image.height))
                frames.append(image_frame)
                continue
            else:
                # Minimal movement for static scenes
                offset_x = int(2 * math.sin(i * 0.05))
                offset_y = int(1 * math.cos(i * 0.05))
            
            # Apply movement
            if offset_x != 0 or offset_y != 0:
                # Create new image with movement
                new_img = Image.new('RGB', image.size, color='black')
                new_img.paste(image, (offset_x, offset_y))
                frames.append(new_img)
            else:
                frames.append(image.copy())
        
        return frames

# Test function for direct usage
def test_enhanced_generator():
    """Test the enhanced generator"""
    print("🧪 Testing Enhanced Video Generator...")
    
    generator = EnhancedVideoGenerator()
    
    test_prompt = "A majestic dragon soars over snow-capped mountains, then descends into a mystical valley"
    
    video_path = generator.create_60_second_video(test_prompt, fps=24)
    
    if video_path:
        print(f"✅ Test successful! Video saved to: {video_path}")
    else:
        print("❌ Test failed!")

if __name__ == "__main__":
    test_enhanced_generator()