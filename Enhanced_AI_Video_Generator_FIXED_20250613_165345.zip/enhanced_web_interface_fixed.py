import gradio as gr
import os
import shutil
from enhanced_video_generator_fixed import EnhancedVideoGenerator
import time
from datetime import datetime
import torch

class EnhancedVideoGeneratorInterface:
    def __init__(self):
        print("🚀 Initializing Enhanced Video Generator Interface...")
        self.generator = EnhancedVideoGenerator()
        
    def generate_video_interface(self, prompt, fps, use_ai_mode, progress=gr.Progress()):
        """Enhanced interface function for Gradio"""
        if not prompt.strip():
            return None, "Please enter a prompt!"
        
        try:
            progress(0.05, desc="Analyzing prompt...")
            
            # Validate inputs
            fps = max(12, min(30, int(fps)))  # Higher FPS for 60s videos
            
            progress(0.1, desc="Creating scene plan...")
            
            # Generate 60-second video
            start_time = time.time()
            
            progress(0.2, desc="Generating enhanced 60-second video...")
            video_path = self.generator.create_60_second_video(
                prompt=prompt,
                fps=fps
            )
            
            end_time = time.time()
            generation_time = end_time - start_time
            
            progress(1.0, desc="Complete!")
            
            if video_path and os.path.exists(video_path):
                file_size = os.path.getsize(video_path) / (1024 * 1024)  # MB
                status_msg = f"""✅ Enhanced 60-second video generated successfully!
                
📁 File: {video_path}
⏱️ Generation time: {generation_time:.1f} seconds
📊 File size: {file_size:.2f} MB
🎞️ FPS: {fps}
🎨 Style: Black background, white subjects
🎵 Audio: Enhanced ambient soundscape
🎬 Duration: Exactly 60 seconds
                """
                return video_path, status_msg
            else:
                return None, "❌ Failed to generate video. Please try again."
                
        except Exception as e:
            return None, f"❌ Error: {str(e)}"
    
    def create_interface(self):
        """Create the enhanced Gradio interface"""
        
        # Custom CSS for professional dark theme
        css = """
        .gradio-container {
            background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%);
            color: #ffffff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .gr-button {
            background: linear-gradient(135deg, #333 0%, #111 100%);
            border: 2px solid #555;
            color: #ffffff;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        .gr-button:hover {
            background: linear-gradient(135deg, #555 0%, #333 100%);
            border-color: #777;
            transform: translateY(-2px);
        }
        .gr-textbox {
            background: #1a1a1a;
            border: 2px solid #333;
            color: #ffffff;
        }
        .gr-slider {
            background: #1a1a1a;
        }
        .gr-checkbox {
            background: #1a1a1a;
        }
        .title-header {
            text-align: center;
            background: linear-gradient(45deg, #333, #666);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        """
        
        with gr.Blocks(
            title="🎬 Enhanced AI Video Generator - 60 Second Black & White Films",
            theme=gr.themes.Monochrome(),
            css=css
        ) as interface:
            
            gr.HTML("""
            <div class="title-header">
                <h1>🎬 Enhanced AI Video Generator</h1>
                <h2>Create Perfect 60-Second Black & White Artistic Films</h2>
                <p><strong>Professional Quality • AI-Powered • Scene-Aware • Perfect Styling</strong></p>
            </div>
            """)
            
            gr.Markdown("""
            ## ✨ What Makes This Special
            
            🎯 **Perfect 60-Second Videos** - Intelligently planned scenes for full-length content  
            🤖 **Advanced AI Integration** - Scene understanding and mood analysis  
            🎨 **Perfect Black & White Style** - Black backgrounds, white subjects, professional contrast  
            🎵 **Scene-Aware Audio** - Dynamic soundscapes that match your content  
            🎞️ **Smooth Cinematic Transitions** - Professional-grade animation and movement  
            
            ---
            """)
            
            with gr.Row():
                with gr.Column(scale=2):
                    prompt_input = gr.Textbox(
                        label="🎬 Enter Your Video Prompt",
                        placeholder="Describe your 60-second film: 'A majestic dragon soars over ancient mountains, then lands in a mystical forest where it meets a wise old wizard'",
                        lines=4,
                        max_lines=8
                    )
                    
                    with gr.Row():
                        fps_slider = gr.Slider(
                            minimum=12,
                            maximum=30,
                            value=24,
                            step=1,
                            label="🎞️ FPS (Frames Per Second)"
                        )
                        
                        ai_mode_checkbox = gr.Checkbox(
                            label="🤖 Use Advanced AI Mode",
                            value=True,
                            info="Enable for highest quality (slower generation)"
                        )
                    
                    generate_btn = gr.Button(
                        "🎬 Generate 60-Second Video",
                        variant="primary",
                        size="lg"
                    )
                
                with gr.Column(scale=1):
                    gr.Markdown("""
                    ### 🎯 Pro Tips for Best Results:
                    
                    **📝 Prompt Writing:**
                    - Describe a journey or story arc
                    - Include scene transitions: "then", "next", "finally"
                    - Mention emotions and atmosphere
                    - Be specific about subjects and actions
                    
                    **🎨 Style Notes:**
                    - All videos have black backgrounds
                    - Subjects appear in white/light tones
                    - High contrast, artistic styling
                    - Professional cinematic quality
                    
                    **⚙️ Technical Settings:**
                    - **24 FPS**: Cinema standard (recommended)
                    - **30 FPS**: Ultra-smooth motion
                    - **AI Mode**: Best quality, slower generation
                    - **Fast Mode**: Quick generation, good quality
                    
                    **🎵 Audio Features:**
                    - Mood-based ambient soundscapes
                    - Scene-synchronized audio changes
                    - Professional reverb and effects
                    """)
            
            with gr.Row():
                video_output = gr.Video(
                    label="🎬 Your 60-Second Masterpiece",
                    height=500
                )
                
                status_output = gr.Textbox(
                    label="📊 Generation Status & Details",
                    lines=8,
                    max_lines=15
                )
            
            # Enhanced example prompts for 60-second videos
            gr.Markdown("""
            ### 🌟 Example 60-Second Film Prompts:
            Click any example to try it out! These are designed for full 60-second narratives.
            """)
            
            examples = [
                [
                    "A majestic dragon soars over snow-capped mountains, then descends into a mystical valley where ancient trees whisper secrets, finally landing beside a crystal-clear lake that reflects the moon",
                    24, True
                ],
                [
                    "A lone lighthouse keeper tends his beacon during a fierce storm, watching ships navigate treacherous waters, then as dawn breaks, he sees a mysterious figure walking on the distant shore",
                    24, True
                ],
                [
                    "A cat begins its journey in a peaceful garden, then ventures into a dark enchanted forest where shadows dance, encounters magical creatures, and finally emerges into a moonlit clearing",
                    24, True
                ],
                [
                    "An ancient castle stands silent in the mist, then its gates slowly open revealing a grand hall, ghostly figures begin to dance, and finally the sun rises dispelling all mysteries",
                    24, True
                ],
                [
                    "A ship sets sail from a bustling harbor, battles through stormy seas with towering waves, discovers a mysterious island, then returns home as the crew shares tales of their adventure",
                    30, True
                ],
                [
                    "A tree grows from a tiny seed in barren desert, seasons change around it, animals find shelter in its branches, then it becomes a mighty oak overlooking a thriving oasis",
                    24, True
                ],
                [
                    "A knight begins his quest at dawn, travels through dark forests and treacherous mountains, faces a mighty dragon in an epic battle, then returns victorious to his kingdom",
                    24, True
                ],
                [
                    "A wolf pack hunts under the full moon, moving silently through snowy wilderness, then they howl together on a mountain peak as aurora dances in the sky above them",
                    24, True
                ]
            ]
            
            gr.Examples(
                examples=examples,
                inputs=[prompt_input, fps_slider, ai_mode_checkbox],
                outputs=[video_output, status_output],
                fn=self.generate_video_interface,
                cache_examples=False
            )
            
            # Event handlers
            generate_btn.click(
                fn=self.generate_video_interface,
                inputs=[prompt_input, fps_slider, ai_mode_checkbox],
                outputs=[video_output, status_output],
                show_progress=True
            )
            
            # Footer with technical details
            gr.Markdown("""
            ---
            
            ### 🔧 Technical Specifications
            
            **🎬 Video Output:**
            - **Duration**: Exactly 60 seconds
            - **Resolution**: 768x768 (optimized for quality)
            - **Format**: MP4 with H.264 encoding
            - **Style**: Black background, white subjects, high contrast
            
            **🤖 AI Technology:**
            - **Scene Analysis**: Advanced NLP for prompt understanding
            - **Image Generation**: Stable Diffusion with custom styling
            - **Animation**: Intelligent frame interpolation
            - **Audio**: Procedural ambient soundscape generation
            
            **🎨 Artistic Features:**
            - **Professional Contrast**: Perfect black/white balance
            - **Cinematic Transitions**: Smooth scene changes
            - **Dynamic Movement**: Subtle motion within scenes
            - **Mood-Based Audio**: Soundscapes that match your story
            
            **⚡ Performance:**
            - **AI Mode**: 2-5 minutes generation time (highest quality)
            - **Fast Mode**: 30-60 seconds generation time (good quality)
            - **Memory Optimized**: Works on various hardware configurations
            
            ---
            
            **🎉 Created with Advanced AI • Perfect for Professional Use • Ready for Google Colab**
            """)
        
        return interface

def main():
    """Launch the enhanced web interface"""
    print("🎬 Starting Enhanced AI Video Generator...")
    print("🚀 Perfect 60-Second Black & White Films with AI")
    
    # Check GPU availability
    if torch.cuda.is_available():
        print(f"🔥 GPU Detected: {torch.cuda.get_device_name()}")
        print("⚡ AI mode will use GPU acceleration")
    else:
        print("💻 Running on CPU - AI mode will be slower but still functional")
    
    # Create interface
    app = EnhancedVideoGeneratorInterface()
    interface = app.create_interface()
    
    # Launch with enhanced settings
    interface.launch(
        server_name="0.0.0.0",
        server_port=7860,  # Standard Gradio port for Colab
        share=True,  # Enable sharing for Colab
        show_error=True,
        max_threads=1  # Prevent memory issues
    )

if __name__ == "__main__":
    main()